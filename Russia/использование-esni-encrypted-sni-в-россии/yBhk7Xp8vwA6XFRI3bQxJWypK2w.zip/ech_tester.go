// by Ori
package main

import (
	"bufio"
	"crypto/tls"
	"errors"
	"fmt"
	"io"
	"log"
	"math/rand/v2"
	"net"
	"net/http"
	"os"
	"os/exec"
	"path/filepath"
	"strings"
	"sync"
	"time"
)

const (
	VERSION     = "1.1"
	PROGRAMNAME = "ECH Batch Tester"
)

var (
	//Unset values
	listFileName string
	lines        []string
	//linesWithECH, linesWithoutECH []string
	filename_ECH, filename_noECH string

	//Preset values
	errExitByChoice = errors.New("terminated by user's choice")

	//Config
	conncurrentThreads           = 50
	connectionTimeout            = 2
	sleepBeforeRequestMS         = 1000
	sleepBeforeRequestThrottleMS = 1500
	retriesIfFailed              = 3
	retriesIfFailedWriteToAFile  = 3
)

var (
	_tlsConfig = &tls.Config{
		InsecureSkipVerify: true,
	}

	_transport = &http.Transport{
		DialContext: (&net.Dialer{
			KeepAlive: 10 * time.Second,
		}).DialContext,
		DisableKeepAlives:   false,
		MaxIdleConns:        conncurrentThreads * 2,
		MaxIdleConnsPerHost: conncurrentThreads,
		IdleConnTimeout:     10 * time.Second,
		//DisableCompression: true,
		//ExpectContinueTimeout: 1 * time.Second,
		TLSClientConfig: _tlsConfig,
	}

	_client = &http.Client{
		Transport: _transport,
		Timeout:   time.Duration(connectionTimeout) * time.Second,
	}
)

func init() {
	err := createLog()
	if err != nil {
		check(fmt.Errorf("can't create log: %v", err))
	}

	err = setTitle(fmt.Sprintf("%s v%s", PROGRAMNAME, VERSION))
	if err != nil {
		check(fmt.Errorf("can't set window title: %v", err))
	}

	listFileName, err = readArgs()
	if err != nil {
		check(fmt.Errorf("can't read argument: %v", err))
	}

	lines, err = readTxtFileReturnLines(listFileName)
	if err != nil {
		check(fmt.Errorf("can't extract lines from a file: %v", err))
	}
	log.Printf("After reading file '%s', %d entries was found.\n", listFileName, len(lines))

	filenameA := strings.Split(filepath.Base(listFileName), ".")
	filename := filenameA[len(filenameA)-2] + "_withoutECH.txt"
	filename_noECH = filepath.Join(filepath.Dir(listFileName), filename)
	err = removeFile(filename_noECH)
	check(err)
	filename = filenameA[len(filenameA)-2] + "_withECH.txt"
	filename_ECH = filepath.Join(filepath.Dir(listFileName), filename)
	err = removeFile(filename_ECH)
	check(err)
}

func main() {

	for i := 0; i < len(lines); i = i + conncurrentThreads {
		thread := 0
		wg := sync.WaitGroup{}
		log.Printf("Making requests %d-%d...\n", i, i+conncurrentThreads-1)
		for thread < conncurrentThreads {
			if (i + thread) >= len(lines) {
				break
			}
			wg.Add(1)
			go sendRequest(&wg, lines[i+thread])
			thread++
		}
		wg.Wait()
	}

	// log.Println("Forming final lists...")
	// filename := strings.Split(filepath.Base(listFileName), ".")
	// filename_converted := filename[len(filename)-2] + "_withoutECH.txt"
	// filefullpath := filepath.Join(filepath.Dir(listFileName), filename_converted)
	// err := saveToFileTxt(filefullpath, linesWithoutECH)
	// if err != nil {
	// 	check(fmt.Errorf("can't save to file: %v", err))
	// } else {
	// 	log.Printf("Websites without ECH support saved to '%s'\n", filefullpath)
	// }
	// filename_converted = filename[len(filename)-2] + "_withECH.txt"
	// filefullpath = filepath.Join(filepath.Dir(listFileName), filename_converted)
	// err = saveToFileTxt(filefullpath, linesWithECH)
	// if err != nil {
	// 	check(fmt.Errorf("can't save to file: %v", err))
	// } else {
	// 	log.Printf("Websites with ECH support saved to '%s'\n", filefullpath)
	// }

	log.Printf("\nAll done\n\nPress [ENTER] to exit...\n")
	fmt.Scanln()

	os.Exit(0)
}

func sendRequest(wg *sync.WaitGroup, website string) {
	defer wg.Done()

	dnsRequest := fmt.Sprintf("https://dns.google/resolve?name=%s&type=HTTPS", website)
	_request, err := http.NewRequest("GET", dnsRequest, nil)
	if err != nil {
		log.Printf("Can't form request for %s: %v\n", website, err)
		writeLineToAFile(filename_noECH, website)
		//linesWithoutECH = append(linesWithoutECH, website)
		return
	}

	retries := retriesIfFailed
	var _response *http.Response
	for retries > 0 {
		retries--
		r := rand.IntN(sleepBeforeRequestThrottleMS) + sleepBeforeRequestMS
		time.Sleep(time.Duration(r) * time.Millisecond)

		_response, err = _client.Do(_request)
		if err == nil && _response != nil {
			break
		} else {
			log.Printf("No response from DNS for %s: %v Attempts left: %d\n", website, err, retries)
			if retries <= 0 {
				//linesWithoutECH = append(linesWithoutECH, website)
				writeLineToAFile(filename_noECH, website)
				return
			}
		}
	}
	defer _response.Body.Close()

	_responseBodyBytes, err := io.ReadAll(_response.Body)
	if err != nil || _responseBodyBytes == nil {
		log.Printf("Can't read response body for %s: %v\n", website, err)
		//linesWithoutECH = append(linesWithoutECH, website)
		writeLineToAFile(filename_noECH, website)
		return
	}

	if strings.Contains(string(_responseBodyBytes), " ech=") {
		log.Printf("SUPPORTS ECH		%s\n", website)
		//linesWithECH = append(linesWithECH, website)
		writeLineToAFile(filename_ECH, website)
	} else {
		log.Printf("NOT SUPPORT ECH		%s\n", website)
		//linesWithoutECH = append(linesWithoutECH, website)
		writeLineToAFile(filename_noECH, website)
	}

	_response.Body.Close()
}

func writeLineToAFile(filename string, line string) {
	r := retriesIfFailedWriteToAFile
	for r > 0 {
		r--
		cmd := exec.Command("cmd", "/C", "echo", line+">>"+filename)
		err := cmd.Run()
		if err != nil {
			log.Printf("Error when writing value '%s' to a file '%s': %v Attempts left: %d\n", line, filename, err, r)
		} else {
			break
		}
	}
}

// func saveToFileTxt(filename string, values []string) error {

// 	file, err := os.Create(filename)
// 	if err != nil {
// 		return fmt.Errorf("can't create file: %v", err)
// 	}
// 	defer file.Close()

// 	w := bufio.NewWriter(file)
// 	for _, value := range values {
// 		fmt.Fprintln(w, value)
// 	}
// 	return w.Flush()
// }

func readTxtFileReturnLines(filename string) ([]string, error) {

	if !strings.EqualFold(filepath.Ext(filename), ".txt") {
		return nil, fmt.Errorf("file extension must be .txt")
	}

	file, err := os.Open(filename)
	if err != nil {
		return nil, fmt.Errorf("can't open file: %v", err)
	}
	defer file.Close()

	var lines []string

	fmt.Println("Reading file, it may take some time...")
	scan := bufio.NewScanner(file)
	for scan.Scan() {
		lines = append(lines, scan.Text())
	}
	return lines, nil
}

func setTitle(t string) error {
	cmd := exec.Command("cmd", "/C", "title", t)
	err := cmd.Run()
	return err
}

func removeFile(filepath string) error {
	if _, err := os.Stat(filepath); err == nil {
		err = os.Remove(filepath)
		if err != nil {
			return fmt.Errorf("can't remove file: %v", err)
		}
	}
	return nil
}

func readArgs() (string, error) {
	if len(os.Args) > 1 {
		a := os.Args[1]
		return a, nil
	} else {
		return "", fmt.Errorf("empty argument")
	}
}

func createLog() error {
	n := "logfile.log"
	if _, err := os.Stat(n); err == nil {
		err = os.Remove(n)
		if err != nil {
			return fmt.Errorf("can't remove previous logfile: %v", err)
		}
	}

	l, err := os.OpenFile(n, os.O_WRONLY|os.O_CREATE|os.O_APPEND, 0200)
	if err != nil {
		return fmt.Errorf("can't write a logfile: %v", err)
	}

	mw := io.MultiWriter(os.Stdout, l)
	// defer l.Close()
	//log = log.New(l, "", 0)
	log.SetFlags(0)
	log.SetOutput(mw)
	log.Println("Log created at", time.Now())
	log.Printf("%s v%s\n\n", PROGRAMNAME, VERSION)

	return nil
}

func check(err error) {
	switch err {
	case nil:
		return
	case errExitByChoice:
		log.Println("Exiting by users choice...")
		os.Exit(0)
	default:
		log.Println("Critical error:", err)
		fmt.Scanln()
		log.Println("Exiting with an error...")
		os.Exit(1)
	}
}
