// by Ori
package main

import (
	"encoding/json"
	"fmt"
	"log"
	"os"
	"strings"
	"time"

	"github.com/AdguardTeam/dnsproxy/upstream"
	"github.com/likexian/whois"
	"github.com/miekg/dns"
)

type dnsResponse struct {
	Response bool
	Zero     bool
	Answer   []dnsAnswer
}

type dnsAnswer struct {
	A    string
	AAAA string
}

var (
	_resolver      = "https://dns.controld.com/comss"
	_ipv           = 4
	_timeout       = 2
	_skipVerify    = true
	_addrToResolve = ""
)

func init() {
	log.SetFlags(0)
	if len(os.Args) == 1 {
		check(fmt.Errorf("no arguments"))
	}
	_addrToResolve = os.Args[1]
}

func main() {
	_r, err := dnsLookup()
	if err != nil {
		check(fmt.Errorf("can't finish DNS lookup: %v", err))
	}
	if !_r.Response || _r.Zero {
		check(fmt.Errorf("response from DNS doesn't contain IP"))
	}
	_ip := readIP(_r)
	if _ip == "" {
		check(fmt.Errorf("no IP found"))
	}
	log.Println("IP:", _ip)
	s, err := doWhoisReturnOrg(_ip)
	if err != nil {
		check(fmt.Errorf("can't find any relevant records: %v", err))
	}
	if s == nil {
		check(fmt.Errorf("can't find any relevant records"))
	}
	for _, line := range s {
		log.Println(line)
	}
	os.Exit(0)
}

func dnsLookup() (dnsResponse, error) {
	var c dnsResponse

	o := &upstream.Options{
		Timeout:            time.Duration(_timeout) * time.Second,
		InsecureSkipVerify: _skipVerify,
		HTTPVersions:       []upstream.HTTPVersion{upstream.HTTPVersion2, upstream.HTTPVersion11},
	}

	u, err := upstream.AddressToUpstream(_resolver, o)
	if err != nil {
		return c, fmt.Errorf("can't create an upstream: %v", err)
	}
	defer u.Close()

	var q = dns.Question{
		Name:   dns.Fqdn(_addrToResolve),
		Qclass: dns.ClassINET,
	}
	q.Qtype = dns.TypeA
	if _ipv == 6 {
		q.Qtype = dns.TypeAAAA
	}

	req := &dns.Msg{}
	req.Id = dns.Id()
	req.RecursionDesired = true
	req.Question = []dns.Question{q}

	resp, err := u.Exchange(req)
	if err != nil {
		return c, fmt.Errorf("can't resolve '%s': %v", _addrToResolve, err)
	}

	var b []byte
	b, err = json.Marshal(resp)
	if err != nil {
		return c, fmt.Errorf("can't marshal json: %v", err)
	}

	err = json.Unmarshal(b, &c)
	if err != nil {
		return c, fmt.Errorf("can't unmarshal json: %v", err)
	}

	return c, nil
}

func readIP(_resp dnsResponse) (_ip string) {
	for _, a := range _resp.Answer {
		switch _ipv {
		case 4:
			if a.A != "" {
				return a.A
			}

		case 6:
			if a.AAAA != "" {
				return a.AAAA
			}
		}
	}
	return ""
}

func doWhoisReturnOrg(_ip string) ([]string, error) {
	result, err := whois.Whois(_ip)
	if err != nil {
		return nil, fmt.Errorf("can't obtain the whois record: %v", err)
	}

	s := strings.Split(string(result), "\n")
	var ss []string
	for _, line := range s {
		if strings.Contains(line, "NetName") {
			ss = append(ss, line)
			continue
		}
		if strings.Contains(line, "Organization") {
			ss = append(ss, line)
			continue
		}
		if strings.Contains(line, "OrgName") {
			ss = append(ss, line)
			continue
		}
		if strings.Contains(line, "OrgId") {
			ss = append(ss, line)
			continue
		}
	}
	return ss, nil
}

func check(err error) {
	switch err {
	case nil:
		return
	default:
		log.Println("Critical error:", err)
		os.Exit(1)
	}
}
