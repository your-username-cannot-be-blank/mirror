// by Ori
package main

import (
	"bufio"
	"encoding/json"
	"fmt"
	"io"
	"log"
	"net"
	"os"
	"path/filepath"
	"strings"
	"sync"
	"time"

	"github.com/AdguardTeam/dnsproxy/upstream"
	"github.com/likexian/whois"
	"github.com/miekg/dns"
)

type dnsResponse struct {
	Response bool
	Zero     bool
	Answer   []dnsAnswer
}

type dnsAnswer struct {
	A    string
	AAAA string
}

const (
	logfile = "logfile.log"
)

var (
	_quiet          = false
	_resolver       = "https://dns.controld.com/comss"
	_ipv            = 4
	_timeout        = 2
	_attemptsLookup = 3
	_attemptsWhois  = 3
	_skipVerify     = true
	_threads        = 10
	_lineToSearch   = "CONTROLD"

	_listName string
	_dialer   = &net.Dialer{}
)

func init() {
	createLog(logfile, _quiet)
	if len(os.Args) == 1 {
		check(fmt.Errorf("no arguments"))
	}
	_listName = os.Args[1]

	whois.DefaultClient.SetTimeout(time.Duration(_timeout) * time.Second)
	_dialer.Timeout = time.Duration(_timeout) * time.Second
	whois.DefaultClient.SetDialer(_dialer)
}

func main() {
	addresses, err := readList(_listName)
	if err != nil {
		check(fmt.Errorf("can't read file: %v", err))
	}
	if addresses == nil {
		check(fmt.Errorf("no urls to check"))
	}
	var addressesFound []string
	for i := 0; i < len(addresses); i = i + _threads {
		log.Printf("Sending request %d-%d\n", i, (i + _threads))
		time.Sleep(200 * time.Millisecond)
		wg := sync.WaitGroup{}
		for j := i; j < i+_threads; j++ {
			if j >= len(addresses) {
				break
			}
			wg.Add(1)
			time.Sleep(100 * time.Millisecond)
			go func(string) {
				defer wg.Done()
				_reply, err := dnsLookup(addresses[j])
				if err != nil {
					log.Printf("Can't finish DNS lookup for '%s': %v\n", addresses[j], err)
					return
				}
				if !_reply.Response || _reply.Zero {
					log.Printf("Response from DNS for '%s' doesn't contain IP\n", addresses[j])
					return
				}
				_ip := returnSingularIP(_reply)
				if _ip == "" {
					log.Printf("No IP found for '%s'\n", addresses[j])
					return
				}
				if _ip == "0.0.0.0" || _ip == "127.0.0.1" {
					log.Printf("URL: %s IP: %s (not a valid IP, ad blockage?; skipping)\n", addresses[j], _ip)
					return
				} else {
					log.Printf("URL: %s IP: %s\n", addresses[j], _ip)
				}
				_line, err := doWhoisIPSearchLine(_ip, _lineToSearch)
				if err != nil {
					log.Printf("Can't finish whois reading for '%s': %v\n", addresses[j], err)
					return
				}
				if _line == "" {
					log.Printf("No mentions of '%s' found in whois record for '%s'\n", _lineToSearch, addresses[j])
				} else {
					log.Printf("Mention of '%s' found in whois record for '%s': %s\n", _lineToSearch, addresses[j], _line)
					addressesFound = append(addressesFound, addresses[j])
				}
			}(addresses[j])
		}
		wg.Wait()
	}
	log.Printf("\n---------------------RESULTS---------------------\n\n")
	if addressesFound == nil {
		log.Printf("No URLs with mentions of '%s' found\n", _lineToSearch)
	} else {
		for _, a := range addressesFound {
			log.Println(a)
		}
	}
	os.Exit(0)
}

func readList(filename string) ([]string, error) {
	f, err := os.Open(filename)
	if err != nil {
		return nil, fmt.Errorf("can't open a file '%s': %v", filename, err)
	}
	defer f.Close()

	var lines []string
	scan := bufio.NewScanner(f)
	for scan.Scan() {
		if scan.Text() != "" {
			lines = append(lines, scan.Text())
		}
	}
	return lines, nil
}

func dnsLookup(addrToResolve string) (dnsResponse, error) {
	var c dnsResponse

	o := &upstream.Options{
		Timeout:            time.Duration(_timeout) * time.Second,
		InsecureSkipVerify: _skipVerify,
		HTTPVersions:       []upstream.HTTPVersion{upstream.HTTPVersion2, upstream.HTTPVersion11},
	}

	u, err := upstream.AddressToUpstream(_resolver, o)
	if err != nil {
		return c, fmt.Errorf("can't create an upstream: %v", err)
	}
	defer u.Close()

	var q = dns.Question{
		Name:   dns.Fqdn(addrToResolve),
		Qclass: dns.ClassINET,
	}
	q.Qtype = dns.TypeA
	if _ipv == 6 {
		q.Qtype = dns.TypeAAAA
	}

	req := &dns.Msg{}
	req.Id = dns.Id()
	req.RecursionDesired = true
	req.Question = []dns.Question{q}

	attempts := _attemptsLookup
	var resp *dns.Msg
	for attempts > 0 {
		resp, err = u.Exchange(req)
		if err != nil {
			log.Printf("Can't resolve '%s' (attempt %d): %v", addrToResolve, attempts, err)
		} else {
			break
		}
		attempts--
		if attempts == 0 {
			return c, fmt.Errorf("can't resolve '%s' (no attempts left): %v", addrToResolve, err)
		}
	}

	var b []byte
	b, err = json.Marshal(resp)
	if err != nil {
		return c, fmt.Errorf("can't marshal json: %v", err)
	}

	err = json.Unmarshal(b, &c)
	if err != nil {
		return c, fmt.Errorf("can't unmarshal json: %v", err)
	}

	return c, nil
}

func returnSingularIP(resp dnsResponse) (_ip string) {
	for _, a := range resp.Answer {
		switch _ipv {
		case 4:
			if a.A != "" {
				return a.A
			}
		case 6:
			if a.AAAA != "" {
				return a.AAAA
			}
		}
	}
	return ""
}

func doWhoisIPSearchLine(ipToWhois string, lineToSearch string) (string, error) {
	var result string
	var err error
	attempts := _attemptsWhois
	for attempts > 0 {
		result, err = whois.Whois(ipToWhois)
		if err != nil {
			log.Printf("Can't obtain a whois record for ip '%s' (attempt %d): %v", ipToWhois, attempts, err)
		} else {
			break
		}
		attempts--
		if attempts == 0 {
			return "", fmt.Errorf("can't obtain a whois record for ip '%s' (no attempts left): %v", ipToWhois, err)
		}
	}

	s := strings.Split(string(result), "\n")
	for _, line := range s {
		if strings.Contains(line, lineToSearch) {
			return line, nil
		}
	}
	return "", nil
}

func createLog(filename string, silentConsole bool) error {
	// removing previous logfile if finded
	if _, err := os.Stat(filename); err == nil {
		err = os.Remove(filename)
		if err != nil {
			return fmt.Errorf("can't remove a file '%s': %v", filename, err)
		}
	}
	// creating log folder if needed
	d := filepath.Dir(filename)
	if d != "." {
		if _, err := os.Stat(d); os.IsNotExist(err) {
			err = os.Mkdir(d, 0200)
			if err != nil {
				return fmt.Errorf("can't create a folder '%s': %v", d, err)
			}
		}
	}
	// creating logfile
	f, err := os.OpenFile(filename, os.O_WRONLY|os.O_CREATE|os.O_APPEND, 0200)
	if err != nil {
		return fmt.Errorf("can't create a file '%s': %v", filename, err)
	}
	// setting output
	if silentConsole {
		log.SetOutput(f)
	} else {
		mw := io.MultiWriter(os.Stdout, f)
		log.SetOutput(mw)
	}
	log.SetFlags(0)
	log.Println("Log created at", time.Now())

	return nil
}

func check(err error) {
	switch err {
	case nil:
		return
	default:
		log.Println("Critical error:", err)
		os.Exit(1)
	}
}
