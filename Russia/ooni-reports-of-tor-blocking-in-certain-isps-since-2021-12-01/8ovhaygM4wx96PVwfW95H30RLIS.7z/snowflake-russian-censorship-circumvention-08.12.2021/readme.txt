Заменить файл в папке Tor Browser по пути Browser/TorBrowser/Tor/PluggableTransports/
Replace file in Tor Browser folder Browser/TorBrowser/Tor/PluggableTransports/

More information:
  https://gitlab.torproject.org/tpo/anti-censorship/pluggable-transports/snowflake/-/issues/40014
  https://ntc.party/t/ooni-reports-of-tor-blocking-in-certain-isps-since-2021-12-01/1477/
