#!/bin/bash
awk '{print $2}' common-https-request-output-10000.txt | sort | uniq -c | sort -hr | awk '{print $0; s+=$1} END {print s}'
awk '{print $2}' padded-https-request-output-10000.txt | sort | uniq -c | sort -hr | awk '{print $0; s+=$1} END {print s}'