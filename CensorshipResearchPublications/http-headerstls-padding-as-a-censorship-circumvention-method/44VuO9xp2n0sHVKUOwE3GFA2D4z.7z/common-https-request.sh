#!/bin/bash
set -o pipefail

echo -n "$1 "
timeout 15 openssl s_client -host "$1" -port 443 -servername "$1" -bugs < /dev/null &> /dev/null
[[ "$?" == "0" ]] && echo "OK" || echo "FAIL"
