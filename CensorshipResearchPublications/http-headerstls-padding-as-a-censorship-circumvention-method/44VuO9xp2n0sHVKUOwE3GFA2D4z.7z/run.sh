#!/bin/bash
parallel --progress -a top-10000.txt -n1 -j40 ./common-https-request.sh {} | tee common-https-request-output-10000.txt
parallel --progress -a top-10000.txt -n1 -j40 ./padded-https-request.sh {} | tee padded-https-request-output-10000.txt
