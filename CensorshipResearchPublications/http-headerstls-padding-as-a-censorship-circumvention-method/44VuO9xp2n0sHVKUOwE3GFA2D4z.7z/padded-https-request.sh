#!/bin/bash
set -o pipefail

echo -n "$1 "
(cd /home/valdikss/Documents/censorship-circumvention-tests/openssl_example/openssl/i/bin &&
 LD_LIBRARY_PATH=../lib SSL_CERT_FILE=/etc/ssl/certs/ca-bundle.trust.crt \
 timeout 15 ./openssl s_client -host "$1" -port 443 -servername "$1" -bugs -nosni_first -add_sni_after_padding < /dev/null &> /dev/null)
[[ "$?" == "0" ]] && echo "OK" || echo "FAIL"
