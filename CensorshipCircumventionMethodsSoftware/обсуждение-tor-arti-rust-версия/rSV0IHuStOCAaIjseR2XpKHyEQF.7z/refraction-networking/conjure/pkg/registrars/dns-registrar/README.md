# DNS registrar

Information for DNS registration are avaliable at the [Github wiki page](https://github.com/refraction-networking/conjure/wiki/DNS-registration).