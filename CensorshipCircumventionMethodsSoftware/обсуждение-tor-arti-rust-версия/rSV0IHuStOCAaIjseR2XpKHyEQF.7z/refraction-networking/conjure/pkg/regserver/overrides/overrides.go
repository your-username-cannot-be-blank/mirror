package overrides

// This package implements the practical overrides for the RegOverrides interface in
// `pkg/core/interfaces`
