# Registration Server Overrides

This package contains implementations for different ways that the registration server can overrides
the parameters sent by clients. In bidirectional registrations this allows / can allow us to do
things like selecting a phantom using a different algorithm, assign phantoms from a non-public set,
change transport parameters to optimize client connections, etc.
