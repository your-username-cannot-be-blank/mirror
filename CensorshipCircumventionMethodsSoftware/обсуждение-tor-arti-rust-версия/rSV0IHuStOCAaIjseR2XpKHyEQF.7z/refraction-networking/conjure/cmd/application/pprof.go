//go:build !debug

package main

func startPProf() {
}
