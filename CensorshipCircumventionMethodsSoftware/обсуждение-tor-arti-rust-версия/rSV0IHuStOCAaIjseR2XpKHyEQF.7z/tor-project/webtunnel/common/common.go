// Package common /*
package common
