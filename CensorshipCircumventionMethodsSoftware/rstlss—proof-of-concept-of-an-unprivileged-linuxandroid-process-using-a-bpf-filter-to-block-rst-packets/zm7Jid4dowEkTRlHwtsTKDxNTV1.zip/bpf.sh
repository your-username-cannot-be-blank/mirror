#!/bin/bash
set -e
unset LD_PRELOAD
ARC="$(getprop ro.product.cpu.abilist)"
BPFURL="http://valdikss.org.ru/bpftest/bpftest"
if [[ "$ARC" =~ "arm64-v8a" ]]; then BPFURL="${BPFURL}-64"; fi
rm bpftest || true
wget -O bpftest "$BPFURL"
chmod 755 bpftest
clear
./bpftest
