#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <linux/filter.h>
#include <linux/bpf.h>
#include <linux/unistd.h>
#include <sys/utsname.h>
#include <unistd.h>

#define BPF_MOV64_IMM(DST, IMM)                 \
    ((struct bpf_insn) {                    \
        .code  = BPF_ALU64 | BPF_MOV | BPF_K,       \
        .dst_reg = DST,                 \
        .src_reg = 0,                   \
        .off   = 0,                 \
        .imm   = IMM })

#define BPF_EXIT_INSN()                     \
    ((struct bpf_insn) {                    \
        .code  = BPF_JMP | BPF_EXIT,            \
        .dst_reg = 0,                   \
        .src_reg = 0,                   \
        .off   = 0,                 \
        .imm   = 0 })

#define LOG_BUF_SIZE 1000
char bpf_log_buf[LOG_BUF_SIZE];

static __u64 ptr_to_u64(const void *ptr)
{
    return (__u64)(unsigned long)ptr;
}

static int bpf_prog_load(enum bpf_prog_type type,
                         const struct bpf_insn *insns, int insn_cnt,
                         const char *license)
{
    union bpf_attr attr = {
        .prog_type = type,
        .insns     = ptr_to_u64(insns),
        .insn_cnt  = insn_cnt,
        .license   = ptr_to_u64(license),
        .log_buf   = ptr_to_u64(bpf_log_buf),
        .log_size  = LOG_BUF_SIZE,
        .log_level = 1,
    };

    return syscall(__NR_bpf, BPF_PROG_LOAD, &attr, sizeof(attr));
    //return bpf(BPF_PROG_LOAD, &attr, sizeof(attr));
}

int main() {
    int sock, ret, ebpf;
    struct utsname un;
    char buf[16] = {0};
    FILE *fp = NULL;

    struct sock_filter cbpf_code[] = {
        { 0x6, 0, 0, 0x00040000 },
    };

    struct sock_fprog cbpf = {
        .len = 1,
        .filter = cbpf_code,
    };

    struct bpf_insn ebpf_code[] = {
        BPF_MOV64_IMM(BPF_REG_0, 0), // r0 = 0
        BPF_EXIT_INSN(),             // return r0
    };

    puts("BPF test v1");
    if (uname(&un) == 0) {
        printf("Kernel version: %s\n", un.release);
    }

    fp = fopen("/proc/sys/kernel/unprivileged_bpf_disabled", "r");
    if (fp) {
        fread(buf, sizeof(buf)-1, 1, fp);
        fclose(fp);
        printf("unprivileged_bpf_disabled = %s\n", buf);
    }

    puts("ro.build.version.release:");
    system("getprop ro.build.version.release");
    puts("ro.product.manufacturer:");
    system("getprop ro.product.manufacturer");
    puts("ro.product.model:");
    system("getprop ro.product.model");

    // cBPF
    puts("");
    puts("Starting cBPF test");
    sock = socket(AF_INET, SOCK_STREAM, 0);
    if (sock < 0) {
        perror("Can't create TCP socket");
        exit(EXIT_FAILURE);
    }

    ret = setsockopt(sock, SOL_SOCKET, SO_ATTACH_FILTER, &cbpf, sizeof(cbpf));
    if (ret < 0)
        perror("Can't attach cBPF to socket");
    else
        puts("Successfully attached cBPF filter to TCP socket!");
    close(sock);
    puts("");

    // eBPF
    puts("Starting eBPF test");
    sock = socket(AF_INET, SOCK_STREAM, 0);
    if (sock < 0) {
        perror("Can't create TCP socket");
        exit(EXIT_FAILURE);
    }

    ebpf = bpf_prog_load(BPF_PROG_TYPE_SOCKET_FILTER, ebpf_code,
                         sizeof(ebpf_code) / sizeof(struct bpf_insn), "GPL");
    if (ebpf < 0) {
        perror("eBPF FD < 0");
        exit(EXIT_FAILURE);
    }

    ret = setsockopt(sock, SOL_SOCKET, SO_ATTACH_BPF, &ebpf, sizeof(ebpf));
    if (ret < 0)
        perror("Can't attach eBPF to socket");
    else
        puts("Successfully attached eBPF filter to TCP socket!");
    close(ebpf);
    close(sock);

    return 0;
}
