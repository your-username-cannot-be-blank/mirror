'use strict';
chrome.runtime.openOptionsPage(() => { console.log('Opened') });