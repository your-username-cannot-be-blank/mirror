'use strict';

chrome.runtime.getBackgroundPage( (bgWindow) => {

      window.winChrome = window.chrome;
      window.chrome = bgWindow.chrome;
      winChrome.tabs.query(
        {active: true, currentWindow: true},
        ([tab]) => console.log(tab),
      );
  });
