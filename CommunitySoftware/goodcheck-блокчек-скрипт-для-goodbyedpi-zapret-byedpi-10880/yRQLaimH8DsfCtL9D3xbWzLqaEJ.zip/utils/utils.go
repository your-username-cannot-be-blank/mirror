package utils

import (
	"bufio"
	// "context"
	"errors"
	"fmt"
	"log"

	// "net"
	"net/http"
	"os"
	"os/exec"
	"runtime"
	"strconv"
	"strings"
	"syscall"
	"time"

	"golang.org/x/sys/windows"
)

var (
	errEmptyValue   = errors.New("empty value")
	errNoSuchOption = errors.New("no such option")
)

// cls code by MasterDimmy
func CLS() {
	var cmd *exec.Cmd
	switch runtime.GOOS {
	case "linux":
		cmd = exec.Command("clear")
	case "windows":
		cmd = exec.Command("cmd", "/c", "cls")
	default:
		log.Printf("CLS for %s not implemented\n", runtime.GOOS)
		return
	}
	cmd.Stdout = os.Stdout
	cmd.Run()
}

// elevate code by jerblack
func AmAdmin() bool {
	log.Println("Checking privilegies")
	elevated := windows.GetCurrentProcessToken().IsElevated()
	log.Printf("Admin rights: %v\n", elevated)
	return elevated
}

func RunMeElevated() error {
	log.Println("Relaunching with elevation")

	verb := "runas"
	exe, _ := os.Executable()
	cwd, _ := os.Getwd()
	args := strings.Join(os.Args[1:], " ")

	verbPtr, _ := syscall.UTF16PtrFromString(verb)
	exePtr, _ := syscall.UTF16PtrFromString(exe)
	cwdPtr, _ := syscall.UTF16PtrFromString(cwd)
	argPtr, _ := syscall.UTF16PtrFromString(args)

	var showCmd int32 = 1 //SW_NORMAL

	err := windows.ShellExecute(0, verbPtr, exePtr, argPtr, cwdPtr, showCmd)
	return err
}

func LookForRawOptionInConfig(configFileName string, optionName string) (string, error) {
	c, err := os.Open(configFileName)
	if err != nil {
		return "", err
	}
	defer c.Close()

	scan := bufio.NewScanner(c)
	for scan.Scan() {
		if !IsCommented(scan.Text(), "[") && !IsCommented(scan.Text(), "/") {
			param := strings.Split(scan.Text(), `=`)
			if param[0] == optionName {
				if param[1] != "" {
					return param[1], nil
				} else {
					return "", errEmptyValue
				}
			}
		}
	}
	return "", errNoSuchOption
}

func LookForStringOptionInConfig(configFileName string, optionName string, defaultValue string) string {
	o, err := LookForRawOptionInConfig(configFileName, optionName)
	if err != nil {
		log.Printf("Can't set %s: %s; using default value: %s\n", optionName, err.Error(), defaultValue)
		return defaultValue
	}
	log.Printf("Set %s: %s\n", optionName, o)
	return o
}

func LookForBoolOptionInConfig(configFileName string, optionName string, defaultValue bool) bool {
	o, err := LookForRawOptionInConfig(configFileName, optionName)
	if err != nil {
		log.Printf("Can't set %s: %s; using default value: %t\n", optionName, err.Error(), defaultValue)
		return defaultValue
	}
	v, err := strconv.ParseBool(o)
	if err != nil {
		log.Printf("Can't set %s: %s; using default value: %t\n", optionName, err.Error(), defaultValue)
		return defaultValue
	}
	log.Printf("Set %s: %t\n", optionName, v)
	return v
}

func LookForIntOptionInConfig(configFileName string, optionName string, defaultValue int) int {
	o, err := LookForRawOptionInConfig(configFileName, optionName)
	if err != nil {
		log.Printf("Can't set %s: %s; using default value: %d\n", optionName, err.Error(), defaultValue)
		return defaultValue
	}
	v, err := strconv.Atoi(o)
	if err != nil {
		log.Printf("Can't set %s: %s; using default value: %d\n", optionName, err.Error(), defaultValue)
		return defaultValue
	}
	log.Printf("Set %s: %d\n", optionName, v)
	return v
}

func IsCommented(line string, symbol string) bool {
	if line != "" {
		return string(line[0]) == symbol
	}
	return true
}

func Is64bit() bool {
	arch := runtime.GOARCH
	if arch == "amd64" || arch == "arm64" || arch == "arm64be" || arch == "loong64" || arch == "mips64" || arch == "mips64le" || arch == "ppc64" || arch == "ppc64le" || arch == "riscv64" || arch == "s390x" || arch == "sparc64" || arch == "wasm" {
		return true
	}
	return false
}

func SetTitle(t string) error {
	cmd := exec.Command("cmd", "/C", "title", t)
	err := cmd.Run()
	return err
}

func CheckConnectivity(webaddress string) error {

	_request, _requestError := http.NewRequest("GET", webaddress, nil)
	if _requestError != nil {
		//_request.Body.Close()
		return fmt.Errorf("problem with a request: %w", _requestError)
	}

	// _dialer := &net.Dialer{
	//Resolver: _resolver,
	// }

	_transport := &http.Transport{
		//MaxIdleConns: 0,
		//CloseIdle: true,
		DisableKeepAlives: true,
		//IdleConnTimeout:    5 * time.Second,
		DisableCompression: true,
		//DialContext: _,
	}

	//  _transport.DialContext = func(ctx context.Context, network, addr string) (net.Conn, error) {
	// 	log.Println("address original =", addr)
	// 	if addr == "google.com:443" {
	// 	addr = "104.244.42.129:443"
	// 	log.Println("address modified =", addr)
	// 	}
	// 	return _dialer.DialContext(ctx, network, addr)
	// }

	_client := &http.Client{
		Transport: _transport,
		Timeout:   2 * time.Second,
	}

	_response, _responseError := _client.Do(_request)
	if _responseError != nil {
		//_response.Body.Close()
		return fmt.Errorf("problem with a response: %w", _responseError)
	}
	if _response.StatusCode != 0 {
		return nil
	} else {
		return fmt.Errorf("problem with a response: no response code")
	}
}

func ConvertSecondsToMinutesSeconds(secondsRaw int) string {
	var minutes int = secondsRaw / 60
	var seconds int = secondsRaw % 60
	t := strconv.Itoa(minutes) + " minutes, " + strconv.Itoa(seconds) + " seconds"
	return t
}
