package sitestocheck

import (
	"bufio"
	"goodcheckgo/utils"
	"io"
	"log"
	"net/http"
	"os"
	"strings"
	"time"
)

var (
	//uzpkfa50vqlgb61wrmhc72xsnid83ytoje94-
	//0123456789abcdefghijklmnopqrstuvwxyz-
	clusterDecodeArrayA = [...]string{"u", "z", "p", "k", "f", "a", "5", "0", "v", "q", "l", "g", "b", "6",
		"1", "w", "r", "m", "h", "c", "7", "2", "x", "s", "n", "i", "d", "8", "3", "y", "t", "o", "j", "e", "9", "4", "-"}
	clusterDecodeArrayB = [...]string{"0", "1", "2", "3", "4", "5", "6", "7", "8", "9", "a", "b", "c", "d",
		"e", "f", "g", "h", "i", "j", "k", "l", "m", "n", "o", "p", "q", "r", "s", "t", "u", "v", "w", "x", "y", "z", "-"}
)

type SiteToCheck struct {
	WebAddress   string
	IP           string
	ResponseCode int
}

func NewSiteToCheck(WebAddress string) SiteToCheck {
	s := SiteToCheck{
		WebAddress:   WebAddress,
		IP:           "unknown",
		ResponseCode: 0,
	}
	return s
}

func ReadChecklistFile(filename string) ([]SiteToCheck, error) {
	f, err := os.Open(filename)
	if err != nil {
		return nil, err
	}
	defer f.Close()

	var sites []SiteToCheck

	scan := bufio.NewScanner(f)
	for scan.Scan() {
		if !utils.IsCommented(scan.Text(), "/") {
			site := cleanURL(scan.Text())
			log.Println("Site to check:", site)
			sites = append(sites, NewSiteToCheck(site))
		}
	}
	return sites, nil
}

func cleanURL(url string) string {
	replacer := strings.NewReplacer("http://", "", "https://", "")
	cleanedUrl := replacer.Replace(url)

	cleanedUrl = strings.Split(cleanedUrl, `/`)[0]

	cleanedUrl = "https://" + cleanedUrl

	return cleanedUrl
}

func ExtractCluster(mappingURL string) string {

	log.Println("Attempting to extract cluster codename from", mappingURL)

	_request, err := http.NewRequest("GET", mappingURL, nil)
	if err != nil {
		log.Println("Can't extract cluster: problem with a request:", err)
		return ""
	}

	_transport := &http.Transport{
		DisableKeepAlives: true,
		//MaxIdleConns: 0,
		//IdleConnTimeout:    5 * time.Second,
		DisableCompression: true,
	}
	_client := &http.Client{
		Transport: _transport,
		Timeout:   2 * time.Second,
	}

	_response, err := _client.Do(_request)
	if err != nil {
		log.Println("Can't extract cluster: problem with a response:", err)
		return ""
	}

	_responseBody, err := io.ReadAll(_response.Body)
	if err != nil {
		log.Println("Can't extract cluster: problem when reading a response:", err)
	}

	response := strings.Split(string(_responseBody), ` `)[2]

	return response

}

func ConvertClusterToURL(codename string) string {
	decodedCodename := ""
	for _, letter := range codename {
		l := string(letter)
		for i := 0; i < len(clusterDecodeArrayA); i++ {
			if l == clusterDecodeArrayA[i] {
				decodedCodename = decodedCodename + clusterDecodeArrayB[i]
				break
			}
		}
	}
	decodedCodename = "https://rr1---sn-" + decodedCodename + ".googlevideo.com"
	return decodedCodename
}
