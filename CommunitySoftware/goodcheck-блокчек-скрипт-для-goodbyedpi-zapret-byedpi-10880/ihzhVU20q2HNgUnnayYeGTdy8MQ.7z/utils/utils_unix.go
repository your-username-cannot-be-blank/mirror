//go:build !windows
// +build !windows

package utils

import (
	"fmt"
	"os"
	"os/exec"
	"path"
	"path/filepath"
	"strconv"
	"strings"
	"syscall"
)

const (
	DIR_MASK  = 0744
	FILE_MASK = 0644
)

func CLS() error {
	fmt.Print("\033[H\033[2J")
	return nil
}

func ReturnWindowsVersion() string {
	return "Not windows"
}

func SetTitle(t string) error {
	fmt.Printf("\033]0;%s\007", t)
	return nil
}

func AmAdmin(quiet bool) bool {
	return os.Geteuid() == 0
}

func RunMeElevated(_ bool) error {
	cmd := exec.Command("sudo", append([]string{"-s"}, os.Args...)...)
	if err := syscall.Exec(cmd.Path, cmd.Args, cmd.Environ()); err != nil {
		return err
	}

	return nil
}

func CreateLog(file string, silentConsole bool) error {
	if err := createLog(file, silentConsole); err != nil {
		return err
	}

	// Fix permissions running as root
	if err := chownOriginalUser(file); err != nil {
		return fmt.Errorf("can't set owner for file '%s': %v", file, err)
	}
	if err := chownOriginalUser(filepath.Dir(file)); err != nil {
		return fmt.Errorf("can't set owner for directory '%s': %v", filepath.Dir(file), err)
	}

	return nil
}

func chownOriginalUser(file string) error {
	uid, err := strconv.Atoi(os.Getenv("SUDO_UID"))
	if err != nil {
		return err
	}

	gid, err := strconv.Atoi(os.Getenv("SUDO_GID"))
	if err != nil {
		return err
	}

	return os.Chown(file, uid, gid)
}

func StopAndDeleteServices(snames ...string) error {
	return nil
}

func TaskKill(tasks ...string) error {
	procs, _ := os.ReadDir("/proc")

	for _, task := range tasks {
		name := path.Base(task)
		for _, p := range procs {
			bytes, _ := os.ReadFile(path.Join("/proc", p.Name(), "cmdline"))
			cmdline := string(bytes)

			pid, _ := strconv.Atoi(p.Name())
			if strings.Contains(cmdline, name) {
				syscall.Kill(pid, syscall.SIGKILL)
				break
			}
		}
	}

	return nil
}

func splitArgsWithSpaces(args []string) []string {
	for i := 0; i < len(args); i++ {
		if !strings.Contains(args[i], " ") {
			continue
		}

		splitArgs := strings.Split(args[i], " ")

		args = append(args[:i], append(splitArgs, args[i+1:]...)...)

		i += len(splitArgs) - 1
	}

	return args
}

func trimQuotes(args []string) {
	for i := 0; i < len(args); i++ {
		if !strings.Contains(args[i], `"`) { continue }
		args[i] = strings.Trim(args[i], `" `)
	}
}

func replaceNULWithDevNull(args []string) {
	for i := 0; i < len(args); i++ {
		if args[i] != "NUL" { continue }
		args[i] = "/dev/null"
	}
}

func BuildCmd(prog string, args []string) *exec.Cmd {
	tmp := make([]string, len(args))
	copy(tmp, args)

	// Handle "-o NUL" passed as single argument
	tmp = splitArgsWithSpaces(tmp)
	// Trim quotes from args cause linux handle raw args fine
	trimQuotes(tmp)
	// Replace pathetic NUL with proper /dev/null
	replaceNULWithDevNull(tmp)

	if !path.IsAbs(prog) {
		wd, _ := os.Getwd()
		prog = path.Join(wd, prog)
	}

	exe := exec.Command(prog, tmp...)
	return exe
}

func StopProgram(exe *exec.Cmd) error {
	err := exe.Process.Kill()
	if err != nil {
		return fmt.Errorf("failed to terminate process: %v", err)
	}

	return err
}
