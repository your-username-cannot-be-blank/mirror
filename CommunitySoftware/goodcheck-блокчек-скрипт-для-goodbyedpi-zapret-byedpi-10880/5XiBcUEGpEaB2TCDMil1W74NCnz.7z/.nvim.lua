local overseer = require('overseer')

overseer.register_template({
  name = 'run',
  builder = function()
    return {
      name = 'run',
      cmd = 'go run .',
      components = {
        'default',
        'unique',
        {
          'open_output',
          direction = 'vertical',
          focus = true,
          on_start = 'always',
        }
      },
    }
  end
})
