package utils

import (
	"errors"
	"fmt"
	"io"
	"log"
	"os"
	"os/exec"
	"path/filepath"
	"runtime"
	"strconv"
	"strings"
	"time"
	"unicode/utf8"
)

func IsCommented(line string, symbol string) bool {
	if line != "" {
		return string(line[0]) == symbol
	}
	return true
}

func InsensitiveReplace(s, old, new string) string { //code by Jan Tungli
	if old == new || old == "" {
		return s // avoid allocation
	}
	t := strings.ToLower(s)
	o := strings.ToLower(old)

	// Compute number of replacements.
	n := strings.Count(t, o)
	if n == 0 {
		return s // avoid allocation
	}
	// Apply replacements to buffer.
	var b strings.Builder
	b.Grow(len(s) + n*(len(new)-len(old)))
	start := 0
	for i := 0; i < n; i++ {
		j := start
		if len(old) == 0 {
			if i > 0 {
				_, wid := utf8.DecodeRuneInString(s[start:])
				j += wid
			}
		} else {
			j += strings.Index(t[start:], o)
		}
		b.WriteString(s[start:j])
		b.WriteString(new)
		start = j + len(old)
	}
	b.WriteString(s[start:])
	return b.String()
}

func RemoveFromArrayString(slice []string, num int) []string {
	// if num == len(slice)-1 {
	// 	return slice[:num]
	// }
	return append(slice[:num], slice[num+1:]...)
}

func createLog(file string, silentConsole bool) error {
	if err := os.Remove(file); err != nil && !os.IsNotExist(err) {
		return fmt.Errorf("can't remove file '%s': %v", file, err)
	}

	if err := os.MkdirAll(filepath.Dir(file), DIR_MASK); err != nil {
		return fmt.Errorf("can't create directory for '%s': %v", file, err)
	}
	
	f, err := os.OpenFile(file, os.O_WRONLY|os.O_CREATE|os.O_APPEND, FILE_MASK)
	if err != nil {
		return fmt.Errorf("can't create file '%s': %v", file, err)
	}

	if silentConsole {
		log.SetOutput(f)
	} else {
		log.SetOutput(io.MultiWriter(os.Stdout, f))
	}

	log.SetFlags(0)
	log.Println("Log created at", time.Now())
	return nil
}

func ConvertSecondsToMinutesSeconds(secondsRaw int) string {
	var minutes int = secondsRaw / 60
	var seconds int = secondsRaw % 60
	t := strconv.Itoa(minutes) + " min, " + strconv.Itoa(seconds) + " sec"
	return t
}

func ConvertMillisecondsSecondsToMinutesSeconds(millisecondsRaw int) string {
	var minutes int = millisecondsRaw / 60000
	var seconds int = (millisecondsRaw % 60000) / 1000
	t := strconv.Itoa(minutes) + " min, " + strconv.Itoa(seconds) + " sec"
	return t
}

func Is64bit() bool {
	arch := runtime.GOARCH
	if arch == "amd64" || arch == "arm64" || arch == "arm64be" || arch == "loong64" || arch == "mips64" || arch == "mips64le" || arch == "ppc64" || arch == "ppc64le" || arch == "riscv64" || arch == "s390x" || arch == "sparc64" || arch == "wasm" {
		return true
	}
	return false
}

func UnwrapErrCompletely(err error) error {
	if err == nil {
		return nil
	}
	var errUnwrapped error
	for err != nil {
		errUnwrapped = err
		err = errors.Unwrap(err)
	}
	return errUnwrapped
}

func ReturnArchitecture() string {
	arch := runtime.GOARCH
	return arch
}

func PrintStringArray(str []string) string {
	if len(str) == 0 {
		return ""
	}
	line := str[0]
	for i := 1; i < len(str); i++ {
		line = line + " " + str[i]
	}
	return line
}

func StartProgramWithArguments(prog string, args []string) (*exec.Cmd, error) {
	cmd := BuildCmd(prog, args)
	return cmd, cmd.Start()
}
