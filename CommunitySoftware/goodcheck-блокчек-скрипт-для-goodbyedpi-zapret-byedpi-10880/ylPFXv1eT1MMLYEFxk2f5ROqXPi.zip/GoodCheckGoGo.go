// by Ori
package main

import (
	"fmt"
	"goodcheckgogo/checklist"
	"goodcheckgogo/lookup"
	"goodcheckgogo/options"
	"goodcheckgogo/requestscurl"
	"goodcheckgogo/requestsnative"
	"goodcheckgogo/strategy"
	"goodcheckgogo/utils"
	"log"
	"os"
	"path/filepath"
	"sync"
	"time"

	gochoice "github.com/TwiN/go-choice"
)

const (
	VERSION     = "0.7.0"
	PROGRAMNAME = "GoodCheckGoGo"

	CONFIGFILE      = "config.ini"
	CHECKLISTFOLDER = "Checklists"
	LOGSFOLDER      = "Logs"
	STRATEGYFOLDER  = "StrategiesGoGo"
)

var (
	allStrategies    []strategy.Strategy
	allWebsites      []checklist.Website
	programToUse     options.OptionFoolingProgram
	testMode         int    = -1 // 1 for native, 2 for curl
	resolverOfChoice string = ""
	passes           int    = -1
	testBegun        bool   = false
	ggc              string = ""
	ggcURL           string = ""
	stratlist        string = ""
	checklistfile    string = ""
)

func init() {

	// restrarting as admin if not
	if !utils.AmAdmin() {
		err := utils.RunMeElevated()
		if err != nil {
			check(fmt.Errorf("can't elevate privilegies: %v", err))
		}
		os.Exit(0)
	}

	// creating logfile
	t := time.Now().Format("2006-01-02_15-04-05")
	n := "logfile_" + PROGRAMNAME + "_" + t + ".log"
	err := utils.CreateLog(filepath.Join(LOGSFOLDER, n))
	if err != nil {
		check(fmt.Errorf("can't initialize log: %v", err))
	}

	// writing down some basic info into the log
	log.Printf("%s v%s\n", PROGRAMNAME, VERSION)
	log.Printf("\nOS: %s\nArchitecture: %s\n", utils.ReturnWindowsVersion(), utils.ReturnArchitecture())

	// setting window title
	err = utils.SetTitle(fmt.Sprintf("%s v%s", PROGRAMNAME, VERSION))
	if err != nil {
		check(fmt.Errorf("can't set title: %v", err))
	}

	// clear console window
	err = utils.CLS()
	if err != nil {
		check(fmt.Errorf("can't clear console window: %v", err))
	}

	// parsing config
	log.Printf("\nReading config...\n")
	err = options.ParseConfig(CONFIGFILE)
	if err != nil {
		check(fmt.Errorf("can't parse config: %v", err))
	}
}

func main() {
	var err error

	// program choice
	log.Printf("\nChoosing fooling program...\n")
	programToUse, err = userChooseProgram()
	if err != nil {
		check(fmt.Errorf("can't choose fooling program: %v", err))
	}

	// stopping programs and services
	log.Printf("\nStopping active fooling programs and services...\n")
	var snames []string
	snames = append(snames, options.MyOptions.Gdpi.ServiceNames...)
	snames = append(snames, options.MyOptions.Zapret.ServiceNames...)
	snames = append(snames, options.MyOptions.Ciadpi.ServiceNames...)
	snames = append(snames, options.MyOptions.WinDivert.Value...)
	err = utils.StopAndDeleteServices(snames...)
	if err != nil {
		check(fmt.Errorf("can't properly stop fooling services: %v", err))
	}
	err = utils.TaskKill(options.MyOptions.Gdpi.ExecutableName, options.MyOptions.Zapret.ExecutableName, options.MyOptions.Ciadpi.ExecutableName)
	if err != nil {
		check(fmt.Errorf("can't properly terminate fooling programs: %v", err))
	}

	// strategy list choice
	log.Printf("\nChoosing strategy list...\n")
	stratlist, err = userChooseStrategyList()
	if err != nil {
		check(fmt.Errorf("can't choose strategy list: %v", err))
	}

	// strategy list processing
	log.Printf("\nParsing strategy list...\n")
	allStrategies, err = strategy.ReadStrategies(filepath.Join(STRATEGYFOLDER, programToUse.ProgramName, stratlist))
	if err != nil {
		check(fmt.Errorf("can't parse strategy list: %v", err))
	}
	if programToUse.WorksAsProxy && strategy.Proxy == "noproxy" {
		check(fmt.Errorf("choosen program works as proxy, but proxy itself is unset"))
	}

	// test mode choice
	log.Printf("\nChoosing requests mode...\n")
	testMode, err = userChooseTestMode()
	if err != nil {
		check(fmt.Errorf("can't choose requests mode: %v", err))
	}

	// connectivity check
	if options.MyOptions.NetConnTest.Value {
		log.Printf("\nChecking '%s' connectivity...\n", strategy.ProtoFull)
		switch testMode {
		case 1:
			// native
			requestsnative.SetTransport(5, 2)
			err = requestsnative.CheckConnectivityNative()
			if err == nil {
				break
			}
			if options.MyOptions.SkipCertVerify.Value {
				check(fmt.Errorf("connectivity test failed: %v", err))
			}
			options.MyOptions.SkipCertVerify.Value = true
			requestsnative.SetTransport(5, 2)
			log.Println("Normal connectivity test failed, switching mode to insecure")
			err = requestsnative.CheckConnectivityNative()
			if err != nil {
				check(fmt.Errorf("connectivity test failed: %v", err))
			}
			err := userChooseContinueInsecure()
			if err != nil {
				check(fmt.Errorf("can't choose whether to continue or not: %v", err))
			}
		case 2:
			// curl
			c, err := requestscurl.CheckConnectivityCurl()
			if err != nil {
				check(fmt.Errorf("connectivity test failed: %v", err))
			}
			if c {
				break
			}
			if options.MyOptions.SkipCertVerify.Value {
				check(fmt.Errorf("connectivity test failed"))
			}
			options.MyOptions.SkipCertVerify.Value = true
			log.Println("Normal connectivity test failed, switching mode to insecure")
			c, err = requestscurl.CheckConnectivityCurl()
			if err != nil {
				check(fmt.Errorf("connectivity test failed: %v", err))
			}
			if !c {
				check(fmt.Errorf("connectivity test failed"))
			}
			err = userChooseContinueInsecure()
			if err != nil {
				check(fmt.Errorf("can't choose whether to continue or not: %v", err))
			}
		default:
			check(fmt.Errorf("schrodinger's cat: 'testMode' value is out of bounds: '%d'", testMode))
		}
	} else {
		log.Printf("\nSkipping connectivity test...\n")
	}

	// resolver connectivity test
	if options.MyOptions.UseDoH.Value {
		domainOnly := utils.InsensitiveReplace(options.MyOptions.NetConnTestURL.Value, "https://", "")
		switch testMode {
		case 1:
			// native
			log.Printf("\nChecking DNS resolvers availability (Native)...\n")
			for _, resolver := range options.MyOptions.DoHResolvers.Value {
				log.Printf("Testing '%s' resolver, looking up ipv4 for '%s'...\n", resolver, domainOnly)
				dnsResult, err := lookup.DnsLookup(resolver, domainOnly, 4, options.MyOptions.ResolverTimeout.Value, options.MyOptions.SkipCertVerify.Value)
				if err != nil {
					check(fmt.Errorf("can't finish DNS lookup: %v", err))
				}
				if !dnsResult.Response {
					log.Println("No response from DNS, trying next one...")
					continue
				}
				if dnsResult.Zero {
					log.Println("Zero response from DNS, trying next one...")
					continue
				}
				var _ip string
				for _, answer := range dnsResult.Answer {
					if answer.A != "" {
						_ip = answer.A
						break
					}
				}
				if _ip == "" {
					log.Println("No valid IP was found, trying next one...")
					continue
				}
				resolverOfChoice = resolver
				log.Printf("Resolver seems ok: '%s' -> %s\n", domainOnly, _ip)
				break
			}
			if resolverOfChoice == "" {
				check(fmt.Errorf("all resolvers failed"))
			}
		case 2:
			// curl
			log.Printf("\nChecking DNS resolvers availability (Curl)...\n")
			for _, resolver := range options.MyOptions.DoHResolvers.Value {
				log.Printf("Testing '%s' resolver, looking up ipv4 for '%s'...\n", resolver, domainOnly)
				dnsResult := requestscurl.DnsLookupCurl(resolver, domainOnly)
				if dnsResult == "" {
					log.Println("Can't resolve IP, trying next one...")
					continue
				}
				resolverOfChoice = resolver
				log.Printf("Resolver seems ok: '%s' -> %s\n", domainOnly, dnsResult)
				break
			}
			if resolverOfChoice == "" {
				check(fmt.Errorf("all resolvers failed"))
			}
		}
	} else {
		log.Printf("\nCustom resolver disabled, skipping DNS availability test...\n")
	}

	// checklist choice
	log.Printf("\nChoosing checklist...\n")
	checklistfile, err = userChooseChecklist()
	if err != nil {
		check(fmt.Errorf("can't choose checklist: %v", err))
	}

	// checklist processing
	log.Printf("\nReading checklist...\n")
	allWebsites, err = checklist.ReadChecklist(filepath.Join(CHECKLISTFOLDER, checklistfile))
	if err != nil {
		check(fmt.Errorf("can't read checklist: %v", err))
	}

	// auto GGC
	if options.MyOptions.AutoGGC.Value {
		log.Printf("\nLooking for Google Cache Server URL...\n")
		switch testMode {
		case 1:
			//native
			for _, url := range options.MyOptions.MappingURLs.Value {
				ggc = requestsnative.ExtractClusterNative(url)
				if ggc != "" {
					break
				}
			}
			if ggc != "" {
				ggcURL = checklist.ConvertClusterToURL(ggc)
				log.Println("------------------")
				log.Println("Your googlevideo cluster:", ggc)
				log.Println("Your googlevideo URL:", ggcURL)
				log.Println("------------------")
				allWebsites = append(allWebsites, checklist.NewWebsite(ggcURL))
			} else {
				log.Println("Can't find googlevideo cluster")
			}
		case 2:
			//curl
			for _, url := range options.MyOptions.MappingURLs.Value {
				ggc = requestscurl.ExtractClusterCurl(url)
				if ggc != "" {
					break
				}
			}
			if ggc != "" {
				ggcURL = checklist.ConvertClusterToURL(ggc)
				log.Println("------------------")
				log.Println("Your googlevideo cluster:", ggc)
				log.Println("Your googlevideo URL:", ggcURL)
				log.Println("------------------")
				allWebsites = append(allWebsites, checklist.NewWebsite(ggcURL))
			} else {
				log.Println("Can't find googlevideo cluster")
			}
		}
	} else {
		log.Printf("\nAuto-looking for Google Cache Server disabled, skipping...\n")
	}
	if len(allWebsites) == 0 {
		check(fmt.Errorf("no URLs to check"))
	}

	// resolving
	log.Printf("\nResolving IP addresses...\n")
	switch testMode {
	case 1:
		//native
		for i := 0; i < len(allWebsites); i++ {
			domainOnly := utils.InsensitiveReplace(allWebsites[i].Address, "https://", "")
			dnsResult, err := lookup.DnsLookup(resolverOfChoice, domainOnly, strategy.IPV, options.MyOptions.ResolverTimeout.Value, options.MyOptions.SkipCertVerify.Value)
			if err != nil {
				check(fmt.Errorf("can't finish DNS lookup: %v", err))
			}
			if !dnsResult.Response {
				log.Printf("No response from DNS for '%s'; removing URL from the checklist...\n", domainOnly)
				continue
			}
			if dnsResult.Zero {
				log.Printf("No valid IPv%d was found for '%s'; removing URL from the checklist...\n", strategy.IPV, domainOnly)
				continue
			}
			if strategy.IPV == 4 {
				var _ip string
				for _, answer := range dnsResult.Answer {
					if answer.A != "" {
						_ip = answer.A
						break
					}
				}
				allWebsites[i].IP = _ip
			} else {
				var _ip string
				for _, answer := range dnsResult.Answer {
					if answer.AAAA != "" {
						_ip = answer.AAAA
						break
					}
				}
				allWebsites[i].IP = _ip
			}
			if allWebsites[i].IP != "" {
				allWebsites[i].IsResolved = true
				log.Printf("IPv%d for '%s' was found: %s", strategy.IPV, domainOnly, allWebsites[i].IP)
			} else {
				log.Printf("No valid IPv%d was found for '%s'; removing URL from the checklist...\n", strategy.IPV, domainOnly)
			}
		}
	case 2:
		//curl
		for i := 0; i < len(allWebsites); i++ {
			domainOnly := utils.InsensitiveReplace(allWebsites[i].Address, "https://", "")
			dnsResult := requestscurl.DnsLookupCurl(resolverOfChoice, domainOnly)
			if dnsResult == "" {
				log.Printf("No valid IPv%d was found for '%s'; removing URL from the checklist...\n", strategy.IPV, domainOnly)
				continue
			}
			allWebsites[i].IsResolved = true
			allWebsites[i].IP = dnsResult
			log.Printf("IPv%d for '%s' was found: %s", strategy.IPV, domainOnly, allWebsites[i].IP)
		}
	}
	var w []checklist.Website
	for _, site := range allWebsites {
		if site.IsResolved {
			w = append(w, site)
		}
	}
	n := len(allWebsites)
	allWebsites = w
	n = n - len(allWebsites)
	log.Printf("URLs removed: %d\nURLs left: %d\n", n, len(allWebsites))
	if len(allWebsites) == 0 {
		check(fmt.Errorf("no URLs left"))
	}

	// passes choice
	log.Printf("\nChoosing number of passes...\n")
	passes, err = userChoosePasses()
	if err != nil {
		check(fmt.Errorf("can't choose number of passes: %v", err))
	}

	// time estimation etc
	log.Printf("\nTime estimation...\n")
	err = utils.CLS()
	if err != nil {
		check(fmt.Errorf("can't clear console window: %v", err))
	}
	log.Println("Program:", programToUse.ProgramName)
	if testMode == 1 {
		log.Println("Requests mode: Native")
	} else {
		log.Println("Requests mode: Curl")
	}
	log.Println("Protocol:", strategy.Protocol)
	log.Println("IP version:", strategy.IPV)
	log.Println("Proxy:", strategy.Proxy)
	log.Println("Total strategies:", len(allStrategies))
	log.Println("Total URLs:", len(allWebsites))
	log.Println("Number of passes:", passes)
	log.Println("Timeout:", options.MyOptions.ConnTimeout.Value, "sec")
	estimStepMilliseconds := options.MyOptions.ConnTimeout.Value*1000 + options.MyOptions.InternalTimeoutMs.Value*2 + 100
	estimTMilliseconds := len(allStrategies) * passes * estimStepMilliseconds
	estimT := utils.ConvertMillisecondsSecondsToMinutesSeconds(estimTMilliseconds)
	log.Println("\nEstimated time for a test:", estimT)
	fmt.Println("\nPreparations complete, press [ENTER] to begin...")
	fmt.Scanln()

	// main loop
	startT := time.Now()
	log.Printf("\nTesting started at %s...\n", startT.String())
	totalStrategies := len(allStrategies)
	totalURLs := len(allWebsites)

	if testMode == 1 {
		//requestsnative.SetThreads(len(allWebsites))
		requestsnative.SetTransport(len(allWebsites), options.MyOptions.ConnTimeout.Value)
	}
	var keysCurl []string
	if testMode == 2 {
		keysCurl = requestscurl.FormRequestsKeys(resolverOfChoice, allWebsites)
		log.Println("Curl request line formed:", keysCurl)
	}

	// if testMode == 1 && strategy.Proxy != "noproxy" {
	// 	requestsnative.SetProxy()
	// }

	err = utils.CLS()
	if err != nil {
		check(fmt.Errorf("can't clear console window: %v", err))
	}

	testBegun = true
	for i := 0; i < totalStrategies; i++ {
		log.Printf("\nLaunching '%s', strategy %d/%d: %s\n", programToUse.ProgramName, (i + 1), totalStrategies, allStrategies[i].Keys)
		prog, err := utils.StartProgramWithArguments(programToUse.ExecutableFullPath, allStrategies[i].Keys)
		if err != nil {
			check(fmt.Errorf("can't launch fooling program with arguments: %v", err))
		}
		for j := 1; j <= passes; j++ {
			utils.SetTitle(fmt.Sprintf("%s v%s - Testing - Strategy %d/%d, Pass %d/%d - Time left: %s", PROGRAMNAME, VERSION, (i + 1), totalStrategies, j, passes, estimT))
			estimTMilliseconds = estimTMilliseconds - estimStepMilliseconds
			estimT = utils.ConvertMillisecondsSecondsToMinutesSeconds(estimTMilliseconds)

			log.Printf("Making requests, pass %d/%d...\n", j, passes)
			time.Sleep(time.Duration(options.MyOptions.InternalTimeoutMs.Value) * time.Millisecond)
			switch testMode {
			case 1:
				// native
				wg := sync.WaitGroup{}
				for p := 0; p < totalURLs; p++ {
					wg.Add(1)
					go requestsnative.SendRequest(&wg, &allWebsites[p], allWebsites)
				}
				wg.Wait()
				requestsnative.CloseIdle()
			case 2:
				//curl
				err = requestscurl.SendRequestsAndParse(keysCurl, &allWebsites)
				if err != nil {
					check(fmt.Errorf("can't finish curl requests: %v", err))
				}
			}

			log.Printf("Displaying results...\n")
			totalS := 0
			for n := 0; n < len(allWebsites); n++ {
				var s string
				if allWebsites[n].LastResponseCode == 0 {
					s = "[CODE: 000] FAILURE"
				} else if allWebsites[n].LastResponseCode == -1 {
					s = "[CODE: ERR] ERROR  "
				} else {
					totalS++
					s = fmt.Sprintf("[CODE: %d] SUCCESS", allWebsites[n].LastResponseCode)
				}
				log.Printf("%s\t%s\n", s, allWebsites[n].Address)
				allWebsites[n].LastResponseCode = -1
			}
			log.Printf("Successes: %d/%d\n", totalS, totalURLs)
			if !allStrategies[i].IsTested || allStrategies[i].Successes > totalS {
				allStrategies[i].Successes = totalS
				allStrategies[i].IsTested = true
				log.Printf("Writing it down; worst result for this strategy: %d/%d\n\n", allStrategies[i].Successes, totalURLs)
			} else {
				log.Printf("Skipping it; worst result for this strategy: %d/%d\n\n", allStrategies[i].Successes, totalURLs)
			}
		}
		if allStrategies[i].Successes > 0 {
			allStrategies[i].HasSuccesses = true
			for k := 0; k < totalURLs; k++ {
				if allWebsites[k].MostSuccessfulStrategySuccesses < allStrategies[i].Successes {
					allWebsites[k].MostSuccessfulStrategySuccesses = allStrategies[i].Successes
					allWebsites[k].MostSuccessfulStrategyNum = i
				}
			}
		} else {
			log.Println("This strategy has no successes")
		}
		log.Printf("Terminating program...\n")
		err = utils.StopProgram(prog)
		if err != nil {
			check(fmt.Errorf("can't terminate fooling program: %v", err))
		}
		time.Sleep(time.Duration(options.MyOptions.InternalTimeoutMs.Value) * time.Millisecond)
	}
	utils.SetTitle(fmt.Sprintf("%s v%s - Test completed", PROGRAMNAME, VERSION))
	log.Printf("\nTest ended at %s\n", time.Now().String())
	log.Printf("Total time taken: %s\n", time.Since(startT))

	// final results showcase
	log.Printf("\nDisplaying summary...\n")
	finalResultsShowcase()

	log.Printf("\nAll Done\n")
	fmt.Printf("\nPress [ENTER] to exit...\n")
	fmt.Scanln()
	os.Exit(0)
}

func finalResultsShowcase() {
	if !testBegun {
		return
	}
	totalURLs := len(allWebsites)
	if totalURLs == 0 {
		return
	}
	totalStrategies := len(allStrategies)
	if totalStrategies == 0 {
		return
	}
	log.Printf("\n--------------------RESULTS BY URL---------------------\n")
	var urlsNoSuccess []int
	for i := 0; i < totalURLs; i++ {
		if !allWebsites[i].HasSuccesses {
			urlsNoSuccess = append(urlsNoSuccess, i)
		}
	}
	if len(urlsNoSuccess) > 0 {
		log.Println("\nURLs with NO successes:")
		for i := 0; i < len(urlsNoSuccess); i++ {
			log.Printf("%s | IP: %s\n", allWebsites[urlsNoSuccess[i]].Address, allWebsites[urlsNoSuccess[i]].IP)
		}
	}
	if len(urlsNoSuccess) != totalURLs {
		log.Println("\nURLs with successes:")
		for i := 0; i < totalURLs; i++ {
			if allWebsites[i].HasSuccesses {
				log.Printf("%s | IP: %s | Best strategy: %s", allWebsites[i].Address, allWebsites[i].IP, allStrategies[allWebsites[i].MostSuccessfulStrategyNum].Keys)
			}
		}
	}
	log.Printf("\n------------------RESULTS BY STRATEGY------------------\n")
	for i := 0; i <= totalURLs; i++ {
		var lines []strategy.Strategy
		for _, strat := range allStrategies {
			if strat.Successes == i {
				lines = append(lines, strat)
			}
		}
		if len(lines) > 0 {
			log.Printf("\nStrategies with %d/%d successes:\n", i, totalURLs)
			for _, line := range lines {
				log.Println(line.Keys)
			}
		}
	}
	log.Printf("\n----------------------INFORMATION----------------------\n\n")
	log.Println("Program:", programToUse.ProgramName)
	log.Println("Strategies list:", stratlist)
	log.Println("Checklist:", checklistfile)
	log.Println("Protocol:", strategy.Protocol)
	log.Println("IP version:", strategy.IPV)
	mode := "Native"
	if testMode == 2 {
		mode = "Curl"
	}
	log.Println("Requests mode:", mode)
	if strategy.Proxy != "noproxy" {
		log.Println("Proxy:", strategy.Proxy)
	}
	log.Println("Passes:", passes)
	log.Println("Timeout:", options.MyOptions.ConnTimeout.Value, "sec")
	if resolverOfChoice != "" {
		log.Println("Resolver:", resolverOfChoice)
	} else {
		log.Println("Resolver: System")
	}
	if options.MyOptions.AutoGGC.Value && ggcURL != "" {
		log.Println("Google Video Cluster:", ggc)
		log.Println("Google Video URL:", ggcURL)
	}
}

func userChooseContinueInsecure() error {
	_, _choiceN, err := gochoice.Pick(
		fmt.Sprintln("\nATTENTION: Normal connectivity test failed, but insecure connectivity test succeeded\nEither root certificates are corrupted or your firewall/antivirus software is interfering\n\nContinue anyway? Test results may be compromised if your ISP perform a certificate substitution:"),
		[]string{"Continue in insecure mode", "Exit"},
	)
	if err != nil {
		return fmt.Errorf("problem with a gochoice: %v", err)
	}
	if _choiceN == 1 {
		exitByChoice()
	}
	log.Println("Continuing in insecure mode by user's choice")
	return nil
}

func userChooseProgram() (options.OptionFoolingProgram, error) {
	var programList []string
	if options.MyOptions.Gdpi.IsExist {
		programList = append(programList, options.MyOptions.Gdpi.ProgramName)
	}
	if options.MyOptions.Zapret.IsExist {
		programList = append(programList, options.MyOptions.Zapret.ProgramName)
	}
	if options.MyOptions.Ciadpi.IsExist {
		programList = append(programList, options.MyOptions.Ciadpi.ProgramName)
	}
	programList = append(programList, "Exit")

	choice, _, err := gochoice.Pick(
		fmt.Sprintf("\nATTENTION: '%s' '%s' and '%s' will be closed, their services will be removed\n\nChoose the fooling program to use:", options.MyOptions.Gdpi.ProgramName, options.MyOptions.Zapret.ProgramName, options.MyOptions.Ciadpi.ProgramName),
		programList,
	)
	if err != nil {
		var p options.OptionFoolingProgram
		return p, fmt.Errorf("problem with a gochoice: %v", err)
	}
	switch choice {
	case options.MyOptions.Gdpi.ProgramName:
		log.Printf("Proceeding with '%s'\n", choice)
		return options.MyOptions.Gdpi, nil
	case options.MyOptions.Zapret.ProgramName:
		log.Printf("Proceeding with '%s'\n", choice)
		return options.MyOptions.Zapret, nil
	case options.MyOptions.Ciadpi.ProgramName:
		log.Printf("Proceeding with '%s'\n", choice)
		return options.MyOptions.Ciadpi, nil
	case "Exit":
		exitByChoice()
	}
	var p options.OptionFoolingProgram
	return p, fmt.Errorf("schrodinger's cat: choice out of bounds: '%s'", choice)
}

func userChooseTestMode() (int, error) {
	var modes []string
	if programToUse.WorksAsProxy {
		modes = []string{"Use Curl (only this mode is available when proxy is in use)"}
	} else {
		modes = []string{"Use Native (faster)", "Use Curl (reliable)"}
	}
	modes = append(modes, "Exit")
	choice, _, err := gochoice.Pick(
		"\nChoose requests mode:",
		modes,
	)
	if err != nil {
		return 0, fmt.Errorf("problem with a gochoice: %v", err)
	}
	switch choice {
	case "Exit":
		exitByChoice()
	case "Use Native (faster)":
		log.Println("Proceeding with 'Native'")
		return 1, nil
	case "Use Curl (reliable)":
		log.Println("Proceeding with 'Curl'")
		return 2, nil
	case "Use Curl (only this mode is available when proxy is in use)":
		log.Println("Proceeding with 'Curl' (forced by the use of proxy)")
		return 2, nil
	}
	return 0, fmt.Errorf("schrodinger's cat: choice out of bounds: '%s'", choice)
}

func userChoosePasses() (int, error) {
	var passesVariants = []string{"1", "2", "3", "4", "5", "6", "7", "8", "9"}

	passesVariants = append(passesVariants, "Exit")
	choice, choiceN, err := gochoice.Pick(
		"\nNumber of passes:",
		passesVariants,
	)
	if err != nil {
		return 0, fmt.Errorf("problem with a gochoice: %v", err)
	}
	if choice == "Exit" {
		exitByChoice()
	}
	log.Printf("Proceeding with '%d' pass(es)\n", (choiceN + 1))
	return (choiceN + 1), nil
}

func userChooseChecklist() (string, error) {
	log.Printf("Reading folder '%s'...\n", CHECKLISTFOLDER)
	entries, err := os.ReadDir(CHECKLISTFOLDER)
	if err != nil {
		return "", fmt.Errorf("can't read folder '%s': %v", CHECKLISTFOLDER, err)
	}

	var checklistsInFolder []string
	for _, e := range entries {
		if !e.IsDir() {
			checklistsInFolder = append(checklistsInFolder, e.Name())
		}
	}
	if len(checklistsInFolder) == 0 {
		return "", fmt.Errorf("can't find any checklists in folder '%s'", CHECKLISTFOLDER)
	}

	checklistsInFolder = append(checklistsInFolder, "Exit")
	choice, _, err := gochoice.Pick(
		"\nChoose the checklist:",
		checklistsInFolder,
	)
	if err != nil {
		return "", fmt.Errorf("problem with a gochoice: %v", err)
	}
	if choice == "Exit" {
		exitByChoice()
	}
	log.Printf("Proceeding with '%s'\n", choice)

	return choice, nil
}

func userChooseStrategyList() (string, error) {
	fullpath := filepath.Join(STRATEGYFOLDER, programToUse.ProgramName)
	log.Printf("Reading folder '%s'...\n", fullpath)
	entries, err := os.ReadDir(fullpath)
	if err != nil {
		return "", fmt.Errorf("can't read folder '%s': %v", fullpath, err)
	}

	var strategiesListsInFolder []string
	for _, e := range entries {
		if !e.IsDir() {
			strategiesListsInFolder = append(strategiesListsInFolder, e.Name())
		}
	}
	if len(strategiesListsInFolder) == 0 {
		return "", fmt.Errorf("can't find any strategy lists in folder '%s'", fullpath)
	}

	strategiesListsInFolder = append(strategiesListsInFolder, "Exit")
	choice, _, err := gochoice.Pick(
		"\nChoose the strategy list:",
		strategiesListsInFolder,
	)
	if err != nil {
		return "", fmt.Errorf("problem with a gochoice: %v", err)
	}
	if choice == "Exit" {
		exitByChoice()
	}
	log.Printf("Proceeding with '%s'\n", choice)

	return choice, nil
}

func exitByChoice() {
	log.Println("Exiting by users choice...")
	os.Exit(0)
}

func check(err error) {
	switch err {
	case nil:
		return
	default:
		log.Println("Critical error:", err)
		fmt.Printf("\nPress [ENTER] to exit...\n")
		fmt.Scanln()
		finalResultsShowcase()
		log.Printf("\nExiting with an error...\n")
		os.Exit(1)
	}
}
