package foolingprogram

import (
	"os"
	"os/exec"
	"syscall"
)

type FoolingProg struct {
	Name        string
	executable  string
	serviceName string
	IsExist     bool
}

func NewFoolingProgram(name string, fullPath string, serviceName string) FoolingProg {
	//exe := exec.Command(fullPath)
	e := false
	if _, err := os.Stat(fullPath); err == nil {
		e = true
	}

	fp := FoolingProg{
		Name:        name,
		executable:  fullPath,
		serviceName: serviceName,
		IsExist:     e,
	}
	return fp
}

var exe *exec.Cmd

func (program FoolingProg) StartWithArguments(arguments string) error {
	exe = exec.Command(program.executable)
	exe.SysProcAttr = &syscall.SysProcAttr{CmdLine: " " + arguments}
	err := exe.Start()
	if err != nil {
		return err
	}
	return nil
}

func (program FoolingProg) Stop() error {
	err := exe.Process.Kill()
	if err != nil {
		return err
	}
	return nil
}
