package sitestocheck

import (
	"bufio"
	"goodcheckgo/utils"
	"log"
	"os"
	"strings"
)

type SiteToCheck struct {
	ID           int
	WebAddress   string
	IP           string
	ResponseCode int
}

var defaultUP string = "unknown"
var DefaultResponseCode int = 0
var totalSitesToCheck int = 0

func newSiteToCheck(WebAddress string) SiteToCheck {
	totalSitesToCheck++
	s := SiteToCheck{
		ID:           totalSitesToCheck,
		WebAddress:   WebAddress,
		IP:           defaultUP,
		ResponseCode: DefaultResponseCode,
	}
	return s
}

func ReadChecklistFile(filename string) ([]SiteToCheck, error) {
	f, err := os.Open(filename)
	if err != nil {
		return nil, err
	}
	defer f.Close()

	var sites []SiteToCheck

	scan := bufio.NewScanner(f)
	for scan.Scan() {
		if !utils.IsCommented(scan.Text(), "/") {
			site := cleanURL(scan.Text())
			log.Println("Site to check:", site)
			sites = append(sites, newSiteToCheck(site))
		}
	}
	return sites, nil
}

func cleanURL(url string) string {
	replacer := strings.NewReplacer("http://", "", "https://", "")
	cleanedUrl := replacer.Replace(url)

	cleanedUrl = strings.Split(cleanedUrl, `/`)[0]

	cleanedUrl = "https://" + cleanedUrl

	return cleanedUrl
}
