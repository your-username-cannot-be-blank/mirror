package main

import (
	"errors"
	"fmt"
	"goodcheckgo/foolingprogram"
	"goodcheckgo/sitestocheck"
	"goodcheckgo/strategies"
	"goodcheckgo/utils"
	"io"
	"log"
	"net/http"
	"net/http/httptrace"
	"os"
	"path/filepath"
	"strings"
	"sync"
	"time"

	gochoice "github.com/TwiN/go-choice"
)

const (
	VERSION        = "0.2"
	CONFIGFILENAME = "config.ini"
)

type Options struct {
	connTimeout      int
	logsFolder       string
	checklistsFolder string
	strategiesFolder string
	payloadsFolder   string
	fakeSni          string
	fakeHexRaw       string
	payloadTLS       string
	payloadUDP       string
	programExtraKeys string
}

var (
	options Options

	currentDirectory string

	strategiesToUse []strategies.Strategy
	sitesToCheck    []sitestocheck.SiteToCheck

	gdpi                     foolingprogram.FoolingProg
	zapret                   foolingprogram.FoolingProg
	ciadpi                   foolingprogram.FoolingProg
	availableFoolingPrograms []string
)

func init() {
	var err error

	//Reading current directory
	currentDirectory, err = os.Getwd()
	check(err)

	//Creating log
	options.logsFolder, err = utils.LookForStringOptionInConfig(CONFIGFILENAME, "LogsFolder")
	check(err)
	createLog(options.logsFolder)

	//Reading config - General
	options.connTimeout, err = utils.LookForIntOptionInConfig(CONFIGFILENAME, "ConnTimeout")
	check(err)

	//Reading config - Folders
	options.checklistsFolder, err = utils.LookForStringOptionInConfig(CONFIGFILENAME, "ChecklistsFolder")
	check(err)
	options.strategiesFolder, err = utils.LookForStringOptionInConfig(CONFIGFILENAME, "StrategiesFolder")
	check(err)
	options.payloadsFolder, err = utils.LookForStringOptionInConfig(CONFIGFILENAME, "PayloadsFolder")
	check(err)

	//Reading config - Fooling-related
	options.fakeSni, err = utils.LookForStringOptionInConfig(CONFIGFILENAME, "FakeSni")
	check(err)
	options.fakeHexRaw, err = utils.LookForStringOptionInConfig(CONFIGFILENAME, "FakeHexRaw")
	check(err)
	options.payloadTLS, err = utils.LookForStringOptionInConfig(CONFIGFILENAME, "PayloadTLS")
	check(err)
	options.payloadUDP, err = utils.LookForStringOptionInConfig(CONFIGFILENAME, "PayloadUDP")
	check(err)

	//Reading config - Programs
	gdpi = setUpFoolingProgram("GdpiName", "GdpiPath", "GdpiExecutable", "GdpiServiceName")
	if gdpi.IsExist {
		log.Printf("%s found\n", gdpi.Name)
		availableFoolingPrograms = append(availableFoolingPrograms, gdpi.Name)
	}
	zapret = setUpFoolingProgram("ZapretName", "ZapretPath", "ZapretExecutable", "ZapretServiceName")
	if zapret.IsExist {
		log.Printf("%s found\n", zapret.Name)
		availableFoolingPrograms = append(availableFoolingPrograms, zapret.Name)
	}
	ciadpi = setUpFoolingProgram("ByeDPIName", "ByeDPIPath", "ByeDPIExecutable", "ByeDPIServiceName")
	if ciadpi.IsExist {
		log.Printf("%s found\n", ciadpi.Name)
		availableFoolingPrograms = append(availableFoolingPrograms, ciadpi.Name)
	}

}

func main() {

	//User selecting fooling program
	programToUse, err := userChoosingProgramToUse(availableFoolingPrograms)
	check(err)

	//User selecting strategy list
	strategiesToUse, options.programExtraKeys, err = userChoosingStrategiesToUse(programToUse)
	check(err)

	//User selecting checklist
	sitesToCheck, err = userChoosingSitesToCheck()
	check(err)

	startT := time.Now()
	log.Println("Testing begun at", startT.String())

	//Main loop
	totalStrats := len(strategiesToUse)
	totalSites := len(sitesToCheck)
	for i := 0; i < totalStrats; i++ {
		log.Printf("Starting %s with strategy %d/%d: %s\n", programToUse.Name, (i + 1), totalStrats, strategiesToUse[i].StrategyKeys)
		err = programToUse.StartWithArguments(strategiesToUse[i].StrategyKeys)
		check(err)

		log.Println("Making request...")
		wg := sync.WaitGroup{}
		for i := 0; i < totalSites; i++ {
			wg.Add(1)
			go sendRequest(&wg, &sitesToCheck[i])
		}
		wg.Wait()

		log.Println("Terminating program...")
		err = programToUse.Stop()
		check(err)

		log.Println("Displaying result...")
		successes := 0
		for _, site := range sitesToCheck {
			if site.ResponseCode != 0 {
				log.Printf("WORKING		URL: %s | IP: %s | CODE: %d %s\n", site.WebAddress, site.IP, site.ResponseCode, http.StatusText(site.ResponseCode))
				successes++
			} else {
				log.Printf("NOT WORKING	URL: %s | IP: %s | CODE: %d %s\n", site.WebAddress, site.IP, site.ResponseCode, http.StatusText(site.ResponseCode))
			}
		}
		strategiesToUse[i].Successes = successes
		log.Printf("Successes: %d/%d\n", successes, totalSites)
	}

	//Results showcase
	log.Println("All strategies tested, displaying results")

	for j := 0; j <= totalSites; j++ {
		var lines []string
		for _, strat := range strategiesToUse {
			if strat.Successes == j {
				lines = append(lines, strat.StrategyKeys)
			}
		}
		if lines != nil {
			log.Printf("Strategies with %d/%d successes:\n", j, totalSites)
			for _, line := range lines {
				log.Println(line)
			}
		}
	}

	endT := time.Now()
	log.Println("Test ended at", endT.String())
	log.Println("Total time taken:", endT.Sub(startT).String())
	fmt.Scanln()
}

func sendRequest(wg *sync.WaitGroup, site *sitestocheck.SiteToCheck) {
	defer wg.Done()

	_request, _requestError := http.NewRequest("GET", site.WebAddress, nil)
	if _requestError != nil {
		site.ResponseCode = 0
		//_request.Body.Close()
		return
	}

	_trace := &httptrace.ClientTrace{
		GotConn: func(connInfo httptrace.GotConnInfo) {
			site.IP = connInfo.Conn.RemoteAddr().String()
		},
	}
	_request = _request.WithContext(httptrace.WithClientTrace(_request.Context(), _trace))

	// _transport := &http.Transport{
	// 	MaxIdleConns:       300,
	// 	IdleConnTimeout:    5 * time.Second,
	// 	DisableCompression: true,
	// }
	_client := &http.Client{
		//Transport: _transport,
		Timeout: time.Duration(options.connTimeout) * time.Second,
	}

	_response, _responseError := _client.Do(_request)
	if _responseError != nil {
		site.ResponseCode = 0
		//_response.Body.Close()
		return
	}

	site.ResponseCode = _response.StatusCode
}

func userChoosingProgramToUse(choices []string) (*foolingprogram.FoolingProg, error) {
	if len(availableFoolingPrograms) == 0 {
		return nil, errors.New("can't find any fooling program")
	}
	choices = append(choices, "Exit")
	choice, _, err := gochoice.Pick(
		"Choose fooling program to use:",
		choices,
	)
	if err != nil {
		return nil, err
	}
	switch choice {
	case gdpi.Name:
		return &gdpi, nil
	case zapret.Name:
		return &zapret, nil
	case ciadpi.Name:
		return &ciadpi, nil
	case "Exit":
		return nil, errors.New("terminating by user's choice")
	}
	return nil, errors.New("unknown error during fooling program selection")
}

func userChoosingStrategiesToUse(program *foolingprogram.FoolingProg) ([]strategies.Strategy, string, error) {

	fullpath := filepath.Join(currentDirectory, options.strategiesFolder, program.Name)
	entries, err := os.ReadDir(fullpath)
	if err != nil {
		return nil, "", err
	}
	var strategiesListsInFolder []string
	for _, e := range entries {
		if !e.IsDir() {
			strategiesListsInFolder = append(strategiesListsInFolder, e.Name())
		}
	}
	if len(strategiesListsInFolder) == 0 {
		return nil, "", errors.New("can't find any strategy lists")
	}
	strategiesListsInFolder = append(strategiesListsInFolder, "Exit")
	choice, _, err := gochoice.Pick(
		"Choose strategy list to use:",
		strategiesListsInFolder,
	)
	if err != nil {
		return nil, "", err
	}
	if choice == "Exit" {
		return nil, "", errors.New("terminating by user's choice")
	}
	s, o, err := strategies.ReadStrategiesFile(filepath.Join(fullpath, choice))
	if err != nil {
		return nil, "", err
	}

	for i := 0; i < len(s); i++ {
		pTLS := filepath.Join(options.payloadsFolder, options.payloadTLS)
		pUDP := filepath.Join(options.payloadsFolder, options.payloadUDP)
		replacer := strings.NewReplacer("FAKEHEX", options.fakeHexRaw, "FAKESNI", options.fakeSni, "PAYLOADTLS", pTLS, "PAYLOADUDP", pUDP)
		s[i].StrategyKeys = replacer.Replace(s[i].StrategyKeys)
		log.Println("Strategy found:", s[i].StrategyKeys)
	}
	return s, o, nil
}

func userChoosingSitesToCheck() ([]sitestocheck.SiteToCheck, error) {

	fullpath := filepath.Join(currentDirectory, options.checklistsFolder)
	entries, err := os.ReadDir(fullpath)
	if err != nil {
		return nil, err
	}
	var checkListsInFolder []string
	for _, e := range entries {
		if !e.IsDir() {
			checkListsInFolder = append(checkListsInFolder, e.Name())
		}
	}
	if len(checkListsInFolder) == 0 {
		return nil, errors.New("can't find any checklists")
	}
	checkListsInFolder = append(checkListsInFolder, "Exit")
	choice, _, err := gochoice.Pick(
		"Choose checklist to use:",
		checkListsInFolder,
	)
	if err != nil {
		return nil, err
	}
	if choice == "Exit" {
		return nil, errors.New("terminating by user's choice")
	}

	s, err := sitestocheck.ReadChecklistFile(filepath.Join(fullpath, choice))
	if err != nil {
		return nil, err
	}
	return s, nil
}

func setUpFoolingProgram(_name string, _path string, _exe string, _servicename string) foolingprogram.FoolingProg {
	name, err := utils.LookForStringOptionInConfig(CONFIGFILENAME, _name)
	check(err)
	path, err := utils.LookForStringOptionInConfig(CONFIGFILENAME, _path)
	check(err)
	exe, err := utils.LookForStringOptionInConfig(CONFIGFILENAME, _exe)
	check(err)
	sname, err := utils.LookForStringOptionInConfig(CONFIGFILENAME, _servicename)
	check(err)
	fullpath := filepath.Join(path, exe)

	prog := foolingprogram.NewFoolingProgram(
		name,
		fullpath,
		sname,
	)

	return prog
}

func createLog(logsFolder string) {
	pathToLog := filepath.Join(currentDirectory, logsFolder, "logfile.log")
	l, err := os.OpenFile(pathToLog, os.O_WRONLY|os.O_CREATE|os.O_APPEND, 0644)
	if err != nil {
		fmt.Println(err)
		fmt.Scanln()
		os.Exit(1)
	}
	mw := io.MultiWriter(os.Stdout, l)
	// defer l.Close()
	//log = log.New(l, "", 0)
	log.SetFlags(0)
	log.SetOutput(mw)
	log.Println("Log successfully created at", time.Now())
}

func check(err error) {
	if err != nil {
		log.Println("Error:", err)
		fmt.Scanln()
		os.Exit(1)
	}
}
