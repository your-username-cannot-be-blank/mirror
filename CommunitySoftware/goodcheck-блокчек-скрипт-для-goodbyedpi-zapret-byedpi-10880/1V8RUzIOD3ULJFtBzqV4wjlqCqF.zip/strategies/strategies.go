package strategies

import (
	"bufio"
	"goodcheckgo/utils"
	"os"
	"strings"
)

type Strategy struct {
	ID           int
	StrategyKeys string
	Successes    int
}

//var totalStrategies int = 0

func NewStrategy(StrategyKeys string) Strategy {
	//totalStrategies++
	s := Strategy{
		//ID:           totalStrategies,
		StrategyKeys: StrategyKeys,
		Successes:    -1,
	}
	return s
}

func ReadStrategiesFile(filepath string) ([]Strategy, string, error) {
	s, err := os.Open(filepath)
	if err != nil {
		return nil, "", err
	}
	defer s.Close()

	var strategies []Strategy

	scan := bufio.NewScanner(s)
	lineCounter := 0
	strategyExtraKeys := ""
	programExtraKeys := ""
	for scan.Scan() {
		if !utils.IsCommented(scan.Text(), "/") {
			lineCounter++
			if lineCounter <= 2 {
				param := strings.Split(scan.Text(), `#`)
				if param[1] != "" {
					switch param[0] {
					case "StrategyExtraKeys":
						strategyExtraKeys = param[1] + " "
					case "ProgramExtraKeys":
						programExtraKeys = param[1] + ";"
					}
				}
			} else {
				strategies = append(strategies, NewStrategy(strategyExtraKeys+scan.Text()))
			}
		}
	}
	return strategies, programExtraKeys, nil
}
