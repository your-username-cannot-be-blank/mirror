package utils

import (
	"bufio"
	"errors"
	"os"
	"strconv"
	"strings"
)

func LookForStringOptionInConfig(configFileName string, optionName string) (string, error) {
	c, err := os.Open(configFileName)
	if err != nil {
		return "", err
	}
	defer c.Close()

	scan := bufio.NewScanner(c)
	for scan.Scan() {
		if !IsCommented(scan.Text(), "[") && !IsCommented(scan.Text(), "/") {
			param := strings.Split(scan.Text(), `=`)
			if param[0] == optionName {
				if param[1] != "" {
					return param[1], nil
				} else {
					return "", errors.New("empty value: " + optionName)
				}
			}
		}
	}
	return "", errors.New("can't find such option: " + optionName)
}

func LookForBoolOptionInConfig(configFileName string, optionName string) (bool, error) {
	o, err := LookForStringOptionInConfig(configFileName, optionName)
	if err != nil {
		return false, err
	}
	v, err := strconv.ParseBool(o)
	if err != nil {
		return false, err
	}
	return v, nil
}

func LookForIntOptionInConfig(configFileName string, optionName string) (int, error) {
	o, err := LookForStringOptionInConfig(configFileName, optionName)
	if err != nil {
		return -1, err
	}
	v, err := strconv.Atoi(o)
	if err != nil {
		return -1, err
	}
	return v, nil
}

func IsCommented(line string, symbol string) bool {
	if line != "" {
		return string(line[0]) == symbol
	}
	return true
}
