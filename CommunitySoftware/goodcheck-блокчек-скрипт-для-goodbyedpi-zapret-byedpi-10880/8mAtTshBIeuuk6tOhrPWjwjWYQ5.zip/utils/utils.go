package utils

import (
	"bufio"
	"crypto/tls"

	// "context"
	"errors"
	"fmt"
	"log"

	// "net"
	"context"
	"net"
	"net/http"
	"os"
	"os/exec"
	"runtime"
	"strconv"
	"strings"
	"syscall"
	"time"

	"golang.org/x/sys/windows/svc"
	"golang.org/x/sys/windows/svc/mgr"

	"golang.org/x/sys/windows"
)

var (
	errEmptyValue   = errors.New("empty value")
	errNoSuchOption = errors.New("no such option")
)

// cls code by MasterDimmy
func CLS() {
	var cmd *exec.Cmd
	switch runtime.GOOS {
	case "linux":
		cmd = exec.Command("clear")
	case "windows":
		cmd = exec.Command("cmd", "/c", "cls")
	default:
		log.Printf("CLS for %s not implemented\n", runtime.GOOS)
		return
	}
	cmd.Stdout = os.Stdout
	cmd.Run()
}

// elevate code by jerblack
func AmAdmin() bool {
	log.Println("Checking privilegies")
	elevated := windows.GetCurrentProcessToken().IsElevated()
	log.Printf("Admin rights: %v\n", elevated)
	return elevated
}

func RunMeElevated() error {
	log.Println("Relaunching with elevation")

	verb := "runas"
	exe, _ := os.Executable()
	cwd, _ := os.Getwd()
	args := strings.Join(os.Args[1:], " ")

	verbPtr, _ := syscall.UTF16PtrFromString(verb)
	exePtr, _ := syscall.UTF16PtrFromString(exe)
	cwdPtr, _ := syscall.UTF16PtrFromString(cwd)
	argPtr, _ := syscall.UTF16PtrFromString(args)

	var showCmd int32 = 1 //SW_NORMAL

	err := windows.ShellExecute(0, verbPtr, exePtr, argPtr, cwdPtr, showCmd)
	return err
}

func LookForRawOptionInConfig(configFileName string, optionName string) (string, error) {
	c, err := os.Open(configFileName)
	if err != nil {
		return "", err
	}
	defer c.Close()

	scan := bufio.NewScanner(c)
	for scan.Scan() {
		if !IsCommented(scan.Text(), "[") && !IsCommented(scan.Text(), "/") {
			param := strings.Split(scan.Text(), `=`)
			if param[0] == optionName {
				if param[1] != "" {
					return param[1], nil
				} else {
					return "", errEmptyValue
				}
			}
		}
	}
	return "", errNoSuchOption
}

func LookForStringOptionInConfig(configFileName string, optionName string, defaultValue string) string {
	o, err := LookForRawOptionInConfig(configFileName, optionName)
	if err != nil {
		log.Printf("Can't set %s: %s; using default value: %s\n", optionName, err.Error(), defaultValue)
		return defaultValue
	}
	log.Printf("Set %s: %s\n", optionName, o)
	return o
}

func LookForBoolOptionInConfig(configFileName string, optionName string, defaultValue bool) bool {
	o, err := LookForRawOptionInConfig(configFileName, optionName)
	if err != nil {
		log.Printf("Can't set %s: %s; using default value: %t\n", optionName, err.Error(), defaultValue)
		return defaultValue
	}
	v, err := strconv.ParseBool(o)
	if err != nil {
		log.Printf("Can't set %s: %s; using default value: %t\n", optionName, err.Error(), defaultValue)
		return defaultValue
	}
	log.Printf("Set %s: %t\n", optionName, v)
	return v
}

func LookForIntOptionInConfig(configFileName string, optionName string, defaultValue int) int {
	o, err := LookForRawOptionInConfig(configFileName, optionName)
	if err != nil {
		log.Printf("Can't set %s: %s; using default value: %d\n", optionName, err.Error(), defaultValue)
		return defaultValue
	}
	v, err := strconv.Atoi(o)
	if err != nil {
		log.Printf("Can't set %s: %s; using default value: %d\n", optionName, err.Error(), defaultValue)
		return defaultValue
	}
	log.Printf("Set %s: %d\n", optionName, v)
	return v
}

func IsCommented(line string, symbol string) bool {
	if line != "" {
		return string(line[0]) == symbol
	}
	return true
}

func Is64bit() bool {
	arch := runtime.GOARCH
	if arch == "amd64" || arch == "arm64" || arch == "arm64be" || arch == "loong64" || arch == "mips64" || arch == "mips64le" || arch == "ppc64" || arch == "ppc64le" || arch == "riscv64" || arch == "s390x" || arch == "sparc64" || arch == "wasm" {
		return true
	}
	return false
}

func ReturnArchitecture() string {
	arch := runtime.GOARCH
	return arch
}

func ReturnWindowsVersion() string {
	if runtime.GOOS == "windows" {
		cmd := exec.Command("cmd", "/C", "ver")
		out, err := cmd.StdoutPipe()
		if err != nil {
			return fmt.Sprintf("unknown: can't pipe cmd: %s", err.Error())
		}
		r := bufio.NewReader(out)
		err = cmd.Start()
		if err != nil {
			return fmt.Sprintf("unknown: can't call cmd: %s", err.Error())
		}
		s, err := r.ReadString(']')
		if err != nil {
			return fmt.Sprintf("unknown: can't parse response: %s", err.Error())
		}
		err = cmd.Wait()
		if err != nil {
			return fmt.Sprintf("unknown: can't properly close pipe: %s", err.Error())
		}
		s = strings.Split(s, "\n")[1]
		return s
	}
	return "Non-Windows"
}

func SetTitle(t string) error {
	cmd := exec.Command("cmd", "/C", "title", t)
	err := cmd.Run()
	return err
}

func CheckConnectivity(webaddress string, skipCertVerify bool) error {

	_request, _requestError := http.NewRequest("GET", webaddress, nil)
	if _requestError != nil {
		//_request.Body.Close()
		return fmt.Errorf("problem with a request: %w", _requestError)
	}

	// _dialer := &net.Dialer{
	//Resolver: _resolver,
	// }

	_tlsConfig := &tls.Config{
		InsecureSkipVerify: skipCertVerify,
	}

	_transport := &http.Transport{
		//MaxIdleConns: 0,
		//CloseIdle: true,
		DisableKeepAlives: true,
		//IdleConnTimeout:    5 * time.Second,
		DisableCompression: true,
		//DialContext: _,
		TLSClientConfig: _tlsConfig,
	}

	//  _transport.DialContext = func(ctx context.Context, network, addr string) (net.Conn, error) {
	// 	log.Println("address original =", addr)
	// 	if addr == "google.com:443" {
	// 	addr = "104.244.42.129:443"
	// 	log.Println("address modified =", addr)
	// 	}
	// 	return _dialer.DialContext(ctx, network, addr)
	// }

	_client := &http.Client{
		Transport: _transport,
		Timeout:   2 * time.Second,
	}

	_response, _responseError := _client.Do(_request)
	if _responseError != nil {
		//_response.Body.Close()
		return fmt.Errorf("problem with a response: %w", _responseError)
	}
	if _response.StatusCode != 0 {
		return nil
	} else {
		return fmt.Errorf("problem with a response: no response code")
	}
}

func CheckConnectivityToResolver(webAddress string, connTimeout int, resolverAddr string, resolverTimeout int, resolverProto string, skipCertVerify bool) bool {

	_resolver := &net.Resolver{
		PreferGo: true,
		Dial: func(ctx context.Context, network, address string) (net.Conn, error) {
			d := net.Dialer{
				Timeout: time.Duration(resolverTimeout) * time.Second,
			}
			return d.DialContext(ctx, resolverProto, resolverAddr)
		},
	}

	_dialer := &net.Dialer{
		Resolver: _resolver,
	}

	_request, _requestError := http.NewRequest("GET", webAddress, nil)
	if _requestError != nil {
		//site.ResponseCode = 0
		//_request.Body.Close()
		return false
	}

	_tlsConfig := &tls.Config{
		InsecureSkipVerify: skipCertVerify,
	}

	_transport := &http.Transport{
		//CloseIdle: true,
		DisableKeepAlives: true,
		//MaxIdleConns: 0,
		//IdleConnTimeout:    5 * time.Second,
		DisableCompression: true,
		//DialContext: _,
		TLSClientConfig: _tlsConfig,
	}

	_transport.DialContext = func(ctx context.Context, network, addr string) (net.Conn, error) {
		//log.Println("address original =", addr)
		// if site.IP != "unknown" {
		// 	addr = site.IP
		// 	log.Println("address modified =", addr)
		// }
		return _dialer.DialContext(ctx, "tcp4", addr)
	}

	_client := &http.Client{
		Transport: _transport,
		Timeout:   time.Duration(connTimeout) * time.Second,
	}

	_, _responseError := _client.Do(_request)

	return _responseError == nil

}

func ConvertSecondsToMinutesSeconds(secondsRaw int) string {
	var minutes int = secondsRaw / 60
	var seconds int = secondsRaw % 60
	t := strconv.Itoa(minutes) + " min, " + strconv.Itoa(seconds) + " sec"
	return t
}

func StopAndDeleteServices(snames []string) error {

	log.Println("Establishing connection to the service manager...")
	manager, err := mgr.Connect()
	if err != nil {
		return fmt.Errorf("can't connect to the service manager: %w", err)
	}
	defer manager.Disconnect()

	for _, sname := range snames {
		log.Printf("Accessing the '%s' service...\n", sname)
		service, err := manager.OpenService(sname)
		if err != nil {
			log.Printf("Can't access the '%s' service, skipping: %s\n", sname, err.Error())
			continue
		}
		defer service.Close()

		log.Println("Sending stop signal...")
		status, err := service.Control(svc.Stop)
		if err != nil && status.State != svc.Stopped {
			return fmt.Errorf("couldn't stop the '%s' service: %v", sname, err)
		}

		log.Println("Deleting the service...")
		err = service.Delete()
		if err != nil && err.Error() != "The specified service has been marked for deletion." {
			return fmt.Errorf("could not delete the service: %v", err)
		}
	}

	log.Println("All done")
	return nil

}

func TaskKill(exe string) error {
	log.Printf("Terminating process '%s'\n", exe)
	cmd := exec.Command("taskkill", "/IM", exe, "/T") //"/F" for force
	err := cmd.Run()
	if err != nil && err.Error() == "exit status 128" {
		log.Println("Process not found")
		return nil
	}
	return err
}
