// by Ori
// todo: color, auto-apply stratagies, http3, doh, wrap errors, proxy for byedpi
package main

import (
	"context"
	"crypto/tls"
	"errors"
	"fmt"
	"goodcheckgo/foolingprogram"
	"goodcheckgo/sitestocheck"
	"goodcheckgo/strategies"
	"goodcheckgo/utils"
	"io"
	"log"
	"net"
	"net/http"
	"net/http/httptrace"
	"os"
	"path/filepath"
	"strconv"
	"strings"
	"sync"
	"time"

	gochoice "github.com/TwiN/go-choice"
)

const (
	PROGRAMNAME    = "GoodCheckGo"
	VERSION        = "0.5.0"
	CONFIGFILENAME = "config.ini"

	LOGSFOLDER       = "Logs"
	CHECKLISTSFOLDER = "Checklists"
	STRATEGIESFOLDER = "StrategiesGo"
	PAYLOADSFOLDER   = "Payloads"
)

type Options struct {
	connTimeout       int
	skipAutoGCS       bool
	fakeSni           string
	fakeHexRaw        string
	payloadTLS        string
	payloadUDP        string
	payloadQUIC       string
	programExtraKeys  string
	netConnTest       bool
	netConnTestURL    string
	requestsProto     string
	resolverUseCustom bool
	resolverAddr      string
	resolverProto     string
	resolverTimeout   int
	skipCertVerify    bool
	winDivertSName    string
}

var (
	currentDirectory string

	options = Options{
		connTimeout:       2,
		skipAutoGCS:       false,
		fakeSni:           "www.google.com",
		fakeHexRaw:        "1603030135010001310303424143facf5c983ac8ff20b819cfd634cbf5143c0005b2b8b142a6cd335012c220008969b6b387683dedb4114d466ca90be3212b2bde0c4f56261a9801",
		payloadTLS:        "tls_earth_google_com.bin",
		payloadUDP:        "quic_ietf_www_google_com.bin",
		payloadQUIC:       "quic_ietf_www_google_com.bin",
		programExtraKeys:  "",
		netConnTest:       true,
		netConnTestURL:    "https://ya.ru",
		requestsProto:     "tcp4",
		resolverUseCustom: true,
		resolverAddr:      "1.1.1.1:53",
		resolverProto:     "tcp4",
		resolverTimeout:   2,
		skipCertVerify:    false,
		winDivertSName:    "WinDivert,WinDivert14",
	}

	resolverFallback = [...]string{
		"1.1.1.1:53", "1.0.0.1:53", "1.1.1.2:53", "8.8.8.8:53", "8.8.4.4:53", "9.9.9.9:53", "9.9.9.10:53",
		"95.85.95.85:53", "2.56.220.2:53", "208.67.222.222:53", "208.67.220.222:53", "77.88.8.8:53",
	}

	mappingURLs = [...]string{"https://redirector.gvt1.com/report_mapping?di=no", "https://redirector.googlevideo.com/report_mapping?di=no"}

	strategiesToUse []strategies.Strategy
	sitesToCheck    []sitestocheck.SiteToCheck

	gdpiDefaults = foolingprogram.NewFoolingProgram(
		"GoodbyeDPI",
		"nil",
		"goodbyedpi.exe",
		"GoodbyeDPI",
	)
	zapretDefaults = foolingprogram.NewFoolingProgram(
		"Zapret",
		"nil",
		"winws.exe",
		"winws1,winws2",
	)
	ciadpiDefaults = foolingprogram.NewFoolingProgram(
		"ByeDPI",
		"nil",
		"ciadpi.exe",
		"ByeDPI",
	)
	gdpi, zapret, ciadpi foolingprogram.FoolingProg

	availableFoolingPrograms []string

	errExitByChoice = errors.New("terminating by user's choice")
)

func init() {
	var err error

	if !utils.AmAdmin() {
		err = utils.RunMeElevated()
		check(err)
		os.Exit(0)
	}

	err = utils.SetTitle(fmt.Sprintf("%s v%s", PROGRAMNAME, VERSION))
	check(err)

	utils.CLS()

	//Reading current directory
	currentDirectory, err = os.Getwd()
	check(err)

	//Creating log
	createLog(LOGSFOLDER)

	//Writing down some general info in the log
	log.Printf("%s v%s\n", PROGRAMNAME, VERSION)
	log.Printf("\nOS: %s\nCPU architecture: %s\n\n", utils.ReturnWindowsVersion(), utils.ReturnArchitecture())

	//Reading config - General
	log.Printf("Reading config: %s\n", CONFIGFILENAME)
	options.connTimeout = utils.LookForIntOptionInConfig(CONFIGFILENAME, "ConnectionTimeoutSec", options.connTimeout)
	options.skipAutoGCS = utils.LookForBoolOptionInConfig(CONFIGFILENAME, "SkipAutoGCS", options.skipAutoGCS)
	options.netConnTest = utils.LookForBoolOptionInConfig(CONFIGFILENAME, "NetConnectivityTest", options.netConnTest)
	options.netConnTestURL = utils.LookForStringOptionInConfig(CONFIGFILENAME, "NetConnectivityTestURL", options.netConnTestURL)
	options.requestsProto = utils.LookForStringOptionInConfig(CONFIGFILENAME, "RequestsProtocol", options.requestsProto)
	options.resolverUseCustom = utils.LookForBoolOptionInConfig(CONFIGFILENAME, "ResolverUseCustom", options.resolverUseCustom)
	options.resolverAddr = utils.LookForStringOptionInConfig(CONFIGFILENAME, "ResolverAddress", options.resolverAddr)
	options.resolverProto = utils.LookForStringOptionInConfig(CONFIGFILENAME, "ResolverProtocol", options.resolverProto)
	options.resolverTimeout = utils.LookForIntOptionInConfig(CONFIGFILENAME, "ResolverTimeoutSec", options.resolverTimeout)
	options.skipCertVerify = utils.LookForBoolOptionInConfig(CONFIGFILENAME, "SkipCertValidation", options.skipCertVerify)
	options.winDivertSName = utils.LookForStringOptionInConfig(CONFIGFILENAME, "WinDivertServiceNames", options.winDivertSName)

	//Reading config - Fooling-related
	options.fakeSni = utils.LookForStringOptionInConfig(CONFIGFILENAME, "FakeSni", options.fakeSni)
	options.fakeHexRaw = utils.LookForStringOptionInConfig(CONFIGFILENAME, "FakeHexRaw", options.fakeHexRaw)
	options.payloadTLS = utils.LookForStringOptionInConfig(CONFIGFILENAME, "PayloadTLS", options.payloadTLS)
	options.payloadQUIC = utils.LookForStringOptionInConfig(CONFIGFILENAME, "PayloadQUIC", options.payloadQUIC)
	options.payloadUDP = utils.LookForStringOptionInConfig(CONFIGFILENAME, "PayloadUDP", options.payloadUDP)

	//Reading config - Programs
	//gdpi
	gdpiSubfolder := "x86"
	if utils.Is64bit() {
		gdpiSubfolder = "x86_64"
	}
	name := utils.LookForStringOptionInConfig(CONFIGFILENAME, "GdpiName", gdpiDefaults.Name)
	path := utils.LookForStringOptionInConfig(CONFIGFILENAME, "GdpiPath", currentDirectory)
	exe := utils.LookForStringOptionInConfig(CONFIGFILENAME, "GdpiExecutable", gdpiDefaults.ExecutableName)
	sname := utils.LookForStringOptionInConfig(CONFIGFILENAME, "GdpiServiceNames", gdpiDefaults.ServiceName)
	gdpi = foolingprogram.NewFoolingProgram(name, path, exe, sname)
	if !gdpi.IsExist {
		gdpi = foolingprogram.NewFoolingProgram(name, filepath.Join(path, gdpiSubfolder), exe, sname)
	}
	if !gdpi.IsExist {
		gdpi = foolingprogram.NewFoolingProgram(gdpiDefaults.Name, currentDirectory, gdpiDefaults.ExecutableName, gdpiDefaults.ServiceName)
	}
	if !gdpi.IsExist {
		gdpi = foolingprogram.NewFoolingProgram(gdpiDefaults.Name, filepath.Join(currentDirectory, gdpiSubfolder), gdpiDefaults.ExecutableName, gdpiDefaults.ServiceName)
	}
	if gdpi.IsExist {
		availableFoolingPrograms = append(availableFoolingPrograms, gdpi.Name)
	}
	//zapret
	name = utils.LookForStringOptionInConfig(CONFIGFILENAME, "ZapretName", zapretDefaults.Name)
	path = utils.LookForStringOptionInConfig(CONFIGFILENAME, "ZapretPath", currentDirectory)
	exe = utils.LookForStringOptionInConfig(CONFIGFILENAME, "ZapretExecutable", zapretDefaults.ExecutableName)
	sname = utils.LookForStringOptionInConfig(CONFIGFILENAME, "ZapretServiceNames", zapretDefaults.ServiceName)
	zapret = foolingprogram.NewFoolingProgram(name, path, exe, sname)
	if !zapret.IsExist {
		zapret = foolingprogram.NewFoolingProgram(name, filepath.Join(path, "zapret-winws"), exe, sname)
	}
	if !zapret.IsExist {
		zapret = foolingprogram.NewFoolingProgram(zapretDefaults.Name, currentDirectory, zapretDefaults.ExecutableName, zapretDefaults.ServiceName)
	}
	if !zapret.IsExist {
		zapret = foolingprogram.NewFoolingProgram(zapretDefaults.Name, filepath.Join(currentDirectory, "zapret-winws"), zapretDefaults.ExecutableName, zapretDefaults.ServiceName)
	}
	if zapret.IsExist {
		availableFoolingPrograms = append(availableFoolingPrograms, zapret.Name)
	}
	//ciadpi
	name = utils.LookForStringOptionInConfig(CONFIGFILENAME, "ByeDPIName", ciadpiDefaults.Name)
	path = utils.LookForStringOptionInConfig(CONFIGFILENAME, "ByeDPIPath", currentDirectory)
	exe = utils.LookForStringOptionInConfig(CONFIGFILENAME, "ByeDPIExecutable", ciadpiDefaults.ExecutableName)
	sname = utils.LookForStringOptionInConfig(CONFIGFILENAME, "ByeDPIServiceNames", ciadpiDefaults.ServiceName)
	ciadpi = foolingprogram.NewFoolingProgram(name, path, exe, sname)
	if !ciadpi.IsExist {
		ciadpi = foolingprogram.NewFoolingProgram(ciadpiDefaults.Name, currentDirectory, ciadpiDefaults.ExecutableName, ciadpiDefaults.ServiceName)
	}
	if ciadpi.IsExist {
		availableFoolingPrograms = append(availableFoolingPrograms, ciadpi.Name)
	}

	//Checking if strategies folder do exist, since it's critical
	_, err = os.Stat(STRATEGIESFOLDER)
	if os.IsNotExist(err) {
		check(fmt.Errorf("strategies folder '%s' doesn't exist", STRATEGIESFOLDER))
	}

	log.Printf("Init completed\n\n")

}

func main() {

	utils.CLS()

	//Stopping programs and services
	log.Printf("Services removal and programs termination\nOffering choice\n")
	var snames []string
	snames = append(snames, strings.Split(gdpi.ServiceName, ",")...)
	snames = append(snames, strings.Split(zapret.ServiceName, ",")...)
	snames = append(snames, strings.Split(ciadpi.ServiceName, ",")...)
	snames = append(snames, strings.Split(options.winDivertSName, ",")...)
	//snames = append(snames, gdpi.ServiceName, zapret.ServiceName, ciadpi.ServiceName)
	//log.Println("Following services will be stopped and deleted:", snames)
	choice, _, err := gochoice.Pick(
		fmt.Sprintf("This programs will be closed: [%s %s %s]\nThis services will be stopped and deleted: %s", gdpi.ExecutableName, zapret.ExecutableName, ciadpi.ExecutableName, snames),
		[]string{"Agree and continue", "Exit"},
	)
	check(err)
	if choice == "Exit" {
		check(errExitByChoice)
	}
	err = utils.TaskKill(gdpi.ExecutableName)
	check(err)
	err = utils.TaskKill(zapret.ExecutableName)
	check(err)
	err = utils.TaskKill(ciadpi.ExecutableName)
	check(err)

	err = utils.StopAndDeleteServices(snames)
	check(err)

	//Check connectivity
	if options.netConnTest {
		log.Printf("\nConnectivity test...\n")
		err := utils.CheckConnectivity(options.netConnTestURL, options.skipCertVerify)
		if err != nil {
			check(fmt.Errorf("net connectivity test failed: %w", err))
		} else {
			log.Println("Connection seems ok")
		}
	} else {
		log.Println("Skipping connectivity test")
	}

	//Check resolver
	if options.resolverUseCustom {
		log.Printf("\nNon-system resolver connectivity test: %s\n", options.resolverAddr)
		if !utils.CheckConnectivityToResolver(options.netConnTestURL, options.connTimeout, options.resolverAddr, options.resolverTimeout, options.resolverProto, options.skipCertVerify) {
			log.Println("Resolver connectivity test failed, trying fallback options...")
			options.resolverAddr = "none"
			for _, r := range resolverFallback {
				log.Printf("Non-system fallback resolver connectivity test: %s\n", r)
				if utils.CheckConnectivityToResolver(options.netConnTestURL, options.connTimeout, r, options.resolverTimeout, options.resolverProto, options.skipCertVerify) {
					log.Println("Resolver seems ok")
					options.resolverAddr = r
					break
				}
			}
		} else {
			log.Println("Resolver seems ok")
		}
		if options.resolverAddr == "none" {
			log.Println("All resolvers failed, returning to system one")
			options.resolverUseCustom = false
		}
	}

	//User selecting fooling program
	programToUse, err := userChoosingProgramToUse(availableFoolingPrograms)
	check(err)

	//User selecting strategy list
	strategiesToUse, options.programExtraKeys, err = userChoosingStrategiesToUse(programToUse)
	check(err)

	//User selecting checklist
	sitesToCheck, err = userChoosingSitesToCheck()
	check(err)

	//User selectiong number of passes
	passes, err := userChoosingNumberOfPasses()
	check(err)

	utils.CLS()

	//Main loop
	totalStrats := len(strategiesToUse)
	totalSites := len(sitesToCheck)
	startT := time.Now()
	timeEstimRaw := totalStrats * passes * options.connTimeout
	timeEstim := utils.ConvertSecondsToMinutesSeconds(timeEstimRaw)

	log.Printf("\nTotal strategies found: %d\nTotal sites in checklist: %d\nNumber of passes: %d\nEstimated time for a test: %s\n\nTest starting up at %s\n\n", totalStrats, totalSites, passes, timeEstim, startT.String())
	for i := 0; i < totalStrats; i++ {
		log.Printf("Launching %s with a strategy %d/%d: %s\n", programToUse.Name, (i + 1), totalStrats, strategiesToUse[i].StrategyKeys)
		err = programToUse.StartWithArguments(strategiesToUse[i].StrategyKeys)
		check(err)

		for j := 1; j <= passes; j++ {
			utils.SetTitle(fmt.Sprintf("%s v%s - Testing - Strategy %d/%d, Pass %d/%d - Time left: %s", PROGRAMNAME, VERSION, (i + 1), totalStrats, j, passes, timeEstim))
			timeEstimRaw = timeEstimRaw - options.connTimeout
			timeEstim = utils.ConvertSecondsToMinutesSeconds(timeEstimRaw)

			log.Printf("Making requests, pass %d/%d...\n", j, passes)
			wg := sync.WaitGroup{}
			for i := 0; i < totalSites; i++ {
				wg.Add(1)
				go sendRequest(&wg, &sitesToCheck[i])
			}
			wg.Wait()

			log.Println("Displaying results...")
			successes := 0
			for _, site := range sitesToCheck {
				if site.ResponseCode != 0 {
					log.Printf("WORKING		URL: %s | IP: %s | CODE: %d %s\n", site.WebAddress, site.IP, site.ResponseCode, http.StatusText(site.ResponseCode))
					successes++
				} else {
					log.Printf("NOT WORKING	URL: %s | IP: %s | CODE: %d %s\n", site.WebAddress, site.IP, site.ResponseCode, http.StatusText(site.ResponseCode))
				}
			}
			log.Printf("Successes: %d/%d\n", successes, totalSites)
			if strategiesToUse[i].Successes == -1 || successes < strategiesToUse[i].Successes {
				strategiesToUse[i].Successes = successes
				log.Printf("Writing it down; worst result for this strategy: %d/%d\n\n", strategiesToUse[i].Successes, totalSites)
			} else {
				log.Printf("Skipping it; worst result for this strategy: %d/%d\n\n", strategiesToUse[i].Successes, totalSites)
			}
		}

		log.Printf("Terminating program...\n\n")
		err = programToUse.Stop()
		check(err)
	}
	utils.SetTitle(fmt.Sprintf("%s v%s - Test completed", PROGRAMNAME, VERSION))
	//Results showcase
	endT := time.Now()
	log.Printf("--- All strategies have been tested, displaying final results ---\n")

	for j := 0; j <= totalSites; j++ {
		var lines []string
		for _, strat := range strategiesToUse {
			if strat.Successes == j {
				lines = append(lines, strat.StrategyKeys)
			}
		}
		if lines != nil {
			log.Printf("\nStrategies with %d/%d successes:\n", j, totalSites)
			for _, line := range lines {
				log.Println(line)
			}
		}
	}

	log.Printf("\nTest ended at %s\n", endT.String())
	log.Printf("Total time taken: %s\n", endT.Sub(startT).String())
	fmt.Scanln()
	log.Println("Exiting...")
	os.Exit(0)
}

func sendRequest(wg *sync.WaitGroup, site *sitestocheck.SiteToCheck) {
	defer wg.Done()

	_resolver := &net.Resolver{
		PreferGo: options.resolverUseCustom,
		Dial: func(ctx context.Context, network, address string) (net.Conn, error) {
			d := net.Dialer{
				Timeout: time.Duration(options.resolverTimeout) * time.Second,
			}
			return d.DialContext(ctx, options.resolverProto, options.resolverAddr)
		},
	}

	_dialer := &net.Dialer{
		Resolver: _resolver,
	}

	_request, _requestError := http.NewRequest("GET", site.WebAddress, nil)
	if _requestError != nil {
		site.ResponseCode = 0
		//_request.Body.Close()
		return
	}

	_trace := &httptrace.ClientTrace{
		GotConn: func(connInfo httptrace.GotConnInfo) {
			site.IP = connInfo.Conn.RemoteAddr().String()
		},
	}
	_request = _request.WithContext(httptrace.WithClientTrace(_request.Context(), _trace))

	_tlsConfig := &tls.Config{
		InsecureSkipVerify: options.skipCertVerify,
	}

	_transport := &http.Transport{
		//CloseIdle: true,
		DisableKeepAlives: true,
		//MaxIdleConns: 0,
		//IdleConnTimeout:    5 * time.Second,
		DisableCompression: true,
		//DialContext: _,
		TLSClientConfig: _tlsConfig,
	}

	_transport.DialContext = func(ctx context.Context, network, addr string) (net.Conn, error) {
		//log.Println("address original =", addr)
		if site.IP != "unknown" {
			addr = site.IP
			//log.Println("address modified =", addr)
		}
		return _dialer.DialContext(ctx, options.requestsProto, addr)
	}

	_client := &http.Client{
		Transport: _transport,
		Timeout:   time.Duration(options.connTimeout) * time.Second,
	}

	_response, _responseError := _client.Do(_request)
	if _responseError != nil {
		site.ResponseCode = 0
		//_response.Body.Close()
		return
	}

	site.ResponseCode = _response.StatusCode
}

func userChoosingProgramToUse(choices []string) (*foolingprogram.FoolingProg, error) {
	log.Printf("\nProgram selection\n")
	if len(availableFoolingPrograms) == 0 {
		return nil, errors.New("can't find any programs")
	}
	choices = append(choices, "Exit")
	log.Println("Offering choice")
	choice, _, err := gochoice.Pick(
		"Choose a program to use:",
		choices,
	)
	if err != nil {
		return nil, err
	}
	switch choice {
	case gdpi.Name:
		log.Printf("Proceeding with: %s\n", choice)
		return &gdpi, nil
	case zapret.Name:
		log.Printf("Proceeding with: %s\n", choice)
		return &zapret, nil
	case ciadpi.Name:
		log.Printf("Proceeding with: %s\n", choice)
		return &ciadpi, nil
	case "Exit":
		return nil, errExitByChoice
	}
	return nil, errors.New("unknown error during program selection")
}

func userChoosingStrategiesToUse(program *foolingprogram.FoolingProg) ([]strategies.Strategy, string, error) {
	log.Printf("\nStrategy selection\n")
	pTLS := setPayload(filepath.Join(currentDirectory, PAYLOADSFOLDER, options.payloadTLS))
	pUDP := setPayload(filepath.Join(currentDirectory, PAYLOADSFOLDER, options.payloadUDP))
	pQUIC := setPayload(filepath.Join(currentDirectory, PAYLOADSFOLDER, options.payloadQUIC))

	fullpath := filepath.Join(currentDirectory, STRATEGIESFOLDER, program.Name)
	entries, err := os.ReadDir(fullpath)
	if err != nil {
		return nil, "", err
	}
	log.Printf("Reading folder: %s\n", fullpath)
	var strategiesListsInFolder []string
	for _, e := range entries {
		if !e.IsDir() {
			strategiesListsInFolder = append(strategiesListsInFolder, e.Name())
		}
	}
	if len(strategiesListsInFolder) == 0 {
		return nil, "", errors.New("can't find any strategy lists")
	}
	strategiesListsInFolder = append(strategiesListsInFolder, "Exit")
	log.Println("Offering choice")
	choice, _, err := gochoice.Pick(
		"Choose strategy list to use:",
		strategiesListsInFolder,
	)
	if err != nil {
		return nil, "", err
	}
	if choice == "Exit" {
		return nil, "", errExitByChoice
	}
	log.Printf("Proceeding with: %s\nReading file...\n", choice)

	s, o, err := strategies.ReadStrategiesFile(filepath.Join(fullpath, choice))
	if err != nil {
		return nil, "", err
	}
	if len(s) == 0 {
		return nil, "", errors.New("strategy list is empty")
	}

	log.Printf("Parsing strategies...\n\n")
	for i := 0; i < len(s); i++ {
		replacer := strings.NewReplacer("FAKEHEX", options.fakeHexRaw, "FAKESNI", options.fakeSni, "PAYLOADTLS", pTLS, "PAYLOADUDP", pUDP, "PAYLOADQUIC", pQUIC)
		s[i].StrategyKeys = replacer.Replace(s[i].StrategyKeys)
		log.Println("Strategy found:", s[i].StrategyKeys)
	}
	return s, o, nil
}

func setPayload(path string) string {
	hex := "0x" + options.fakeHexRaw
	log.Println("Checking if payload exist:", path)
	_, err := os.Stat(path)
	if os.IsNotExist(err) {
		log.Printf("Payload '%s' not found. Using custom hex instead (it may not work!): %s", path, hex)
		return hex
	}
	return path
}

func userChoosingSitesToCheck() ([]sitestocheck.SiteToCheck, error) {
	log.Printf("\nChecklist selection\n")

	foundGCS := false
	var gsc sitestocheck.SiteToCheck
	var sites []sitestocheck.SiteToCheck
	var checkListsInFolder []string

	if !options.skipAutoGCS {
		log.Printf("Searching for Google Cache Server...\n")
		c := ""
		for _, mURL := range mappingURLs {
			c = sitestocheck.ExtractCluster(mURL)
			if c != "" {
				log.Printf("\nYour cluster codename: %s\n", c)
				break
			}
		}
		if c != "" {
			cc := sitestocheck.ConvertClusterToURL(c)
			log.Printf("Your Google Cache Server URL: %s\n\n", cc)
			foundGCS = true
			gsc = sitestocheck.NewSiteToCheck(cc)
			checkListsInFolder = append(checkListsInFolder, "Check only your Google Cache Server")
		} else {
			log.Printf("Cannot find Google Cache Server URL\n\n")
		}
	} else {
		log.Printf("Skipping auto-search for Google Cache Server...\n\n")
	}

	fullpath := filepath.Join(currentDirectory, CHECKLISTSFOLDER)
	log.Printf("Reading folder: %s\n", fullpath)
	if _, err := os.Stat(fullpath); os.IsNotExist(err) {
		log.Println("Folder doesn't exist, creating...")
		err = os.Mkdir(fullpath, 0200)
		check(err)
	}
	entries, err := os.ReadDir(fullpath)
	if err != nil {
		return nil, err
	}
	for _, e := range entries {
		if !e.IsDir() {
			checkListsInFolder = append(checkListsInFolder, e.Name())
		}
	}
	if len(checkListsInFolder) == 0 {
		return nil, errors.New("nothing to check")
	}
	checkListsInFolder = append(checkListsInFolder, "Exit")
	log.Println("Offering choice")
	choice, _, err := gochoice.Pick(
		"Choose checklist to use:",
		checkListsInFolder,
	)
	if err != nil {
		return nil, err
	}
	switch choice {
	case "Exit":
		return nil, errExitByChoice
	case "Check only your Google Cache Server":
		log.Println("Checking only Google Cache Server by user's choice")
		sites = append(sites, gsc)
		return sites, nil
	default:
		log.Printf("Proceeding with: %s\nReading file...\n\n", choice)
	}

	sites, err = sitestocheck.ReadChecklistFile(filepath.Join(fullpath, choice))
	if err != nil {
		return nil, err
	}

	if foundGCS && len(sites) != 0 {
		choice, _, err := gochoice.Pick(
			"Check your Google Cache Server?",
			[]string{"Yes", "No", "Exit"},
		)
		if err != nil {
			return nil, err
		}
		switch choice {
		case "Exit":
			return nil, errExitByChoice
		case "Yes":
			log.Println("Appending Google Cache Server to a checklist by user's choice")
			sites = append(sites, gsc)
		case "No":
			log.Println("Skipping Google Cache Server by user's choice")
		}
	} else if foundGCS && len(sites) == 0 {
		log.Println("Checklist is empty, appending Google Cache Server to a checklist automatically")
		sites = append(sites, gsc)
	} else if !foundGCS && len(sites) == 0 {
		return nil, errors.New("nothing to check")
	}

	return sites, nil
}

func userChoosingNumberOfPasses() (int, error) {
	log.Printf("\nNumber of passes selection\n")

	choices := []string{"1", "2", "3", "4", "5"}
	choices = append(choices, "Exit")

	log.Println("Offering choice")
	choice, _, err := gochoice.Pick(
		"Choose how many passes to do:",
		choices,
	)
	if err != nil {
		return -1, fmt.Errorf("problem during selection: %w", err)
	}
	if choice == "Exit" {
		return -1, errExitByChoice
	}

	c, err := strconv.Atoi(choice)
	if err != nil {
		return -1, fmt.Errorf("problem during string->int conversion: %w", err)
	}
	log.Printf("Proceeding with %d pass(es)\n", c)
	return c, nil
}

func createLog(logsFolder string) {
	t := time.Now().Format("2006-01-02_15-04-05")
	n := "logfile_" + PROGRAMNAME + "_" + t + ".log"
	pathToLog := filepath.Join(currentDirectory, logsFolder, n)
	if _, err := os.Stat(logsFolder); os.IsNotExist(err) {
		err = os.Mkdir(logsFolder, 0200)
		check(err)
	}
	l, err := os.OpenFile(pathToLog, os.O_WRONLY|os.O_CREATE|os.O_APPEND, 0200)
	check(err)
	mw := io.MultiWriter(os.Stdout, l)
	// defer l.Close()
	//log = log.New(l, "", 0)
	log.SetFlags(0)
	log.SetOutput(mw)
	log.Println("Log created at", time.Now())
}

func check(err error) {
	switch err {
	case nil:
		return
	case errExitByChoice:
		log.Println("Exiting by users choice...")
		os.Exit(1)
	default:
		log.Println("Critical error:", err)
		fmt.Scanln()
		log.Println("Exiting with an error...")
		os.Exit(1)
	}
}
