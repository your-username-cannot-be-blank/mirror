package foolingprogram

import (
	"log"
	"os"
	"os/exec"
	"path/filepath"
	"syscall"
)

type FoolingProg struct {
	Name             string
	PathToExecutable string
	ExecutableName   string
	executable       string
	ServiceName      string
	IsExist          bool
}

func NewFoolingProgram(name string, pathToExecutable string, executableName string, serviceName string) FoolingProg {
	//exe := exec.Command(fullPath)
	fullPath := filepath.Join(pathToExecutable, executableName)
	e := false
	if _, err := os.Stat(fullPath); err == nil {
		e = true
		log.Printf("%s executable '%s' found at %s\n", name, executableName, pathToExecutable)
	} else {
		log.Printf("Cannot find %s executable '%s' at %s\n", name, executableName, pathToExecutable)
	}

	fp := FoolingProg{
		Name:             name,
		PathToExecutable: pathToExecutable,
		ExecutableName:   executableName,
		executable:       fullPath,
		ServiceName:      serviceName,
		IsExist:          e,
	}
	return fp
}

var exe *exec.Cmd

func (program FoolingProg) StartWithArguments(arguments string) error {
	exe = exec.Command(program.executable)
	exe.SysProcAttr = &syscall.SysProcAttr{CmdLine: " " + arguments}
	err := exe.Start()
	if err != nil {
		return err
	}
	return nil
}

func (program FoolingProg) Stop() error {
	err := exe.Process.Kill()
	if err != nil {
		return err
	}
	return nil
}
