package foolingprogram

import (
	"fmt"
	"log"
	"os"
	"os/exec"
	"path/filepath"
	"syscall"

	"golang.org/x/sys/windows"
)

type FoolingProg struct {
	Name             string
	PathToExecutable string
	ExecutableName   string
	executable       string
	ServiceName      string
	IsExist          bool
}

func NewFoolingProgram(name string, pathToExecutable string, executableName string, serviceName string) FoolingProg {
	//exe := exec.Command(fullPath)
	fullPath := filepath.Join(pathToExecutable, executableName)
	e := false
	if _, err := os.Stat(fullPath); err == nil {
		e = true
		log.Printf("%s executable '%s' found at %s\n", name, executableName, pathToExecutable)
	} else {
		log.Printf("Cannot find %s executable '%s' at %s\n", name, executableName, pathToExecutable)
	}

	fp := FoolingProg{
		Name:             name,
		PathToExecutable: pathToExecutable,
		ExecutableName:   executableName,
		executable:       fullPath,
		ServiceName:      serviceName,
		IsExist:          e,
	}
	return fp
}

//var exe *exec.Cmd

func (program FoolingProg) StartWithArguments(arguments string) (*exec.Cmd, error) {
	exe := exec.Command(program.executable)
	exe.SysProcAttr = &syscall.SysProcAttr{CmdLine: " " + arguments}
	err := exe.Start()
	if err != nil {
		return exe, err
	}
	return exe, nil
}

func Stop(exe *exec.Cmd) error {
	exist, err := PidExists(int32(exe.Process.Pid))
	if err != nil {
		return fmt.Errorf("failed to properly check if process do exist: %w", err)
	}
	if exist {
		err = exe.Process.Kill()
		if err != nil {
			return fmt.Errorf("failed to properly kill process: %w", err)
		}
	} else {
		log.Println("Can't find process: either it wasn't properly started, crushed or something already terminated it")
	}
	return nil
}

// code by shirou
func PidExists(pid int32) (bool, error) {
	if pid == 0 { // special case for pid 0 System Idle Process
		return true, nil
	}
	if pid < 0 {
		return false, fmt.Errorf("invalid pid %v", pid)
	}
	if pid%4 != 0 {
		// OpenProcess will succeed even on non-existing pid here https://devblogs.microsoft.com/oldnewthing/20080606-00/?p=22043
		return false, fmt.Errorf("pid %v incorrect: it should be a multiplier of 4", pid)
	}
	const STILL_ACTIVE = 259 // https://docs.microsoft.com/en-us/windows/win32/api/processthreadsapi/nf-processthreadsapi-getexitcodeprocess
	h, err := windows.OpenProcess(windows.PROCESS_QUERY_LIMITED_INFORMATION, false, uint32(pid))
	if err == windows.ERROR_ACCESS_DENIED {
		return true, nil
	}
	if err == windows.ERROR_INVALID_PARAMETER {
		return false, nil
	}
	if err != nil {
		return false, err
	}
	defer syscall.CloseHandle(syscall.Handle(h))
	var exitCode uint32
	err = windows.GetExitCodeProcess(h, &exitCode)
	return exitCode == STILL_ACTIVE, err
}
