// by Ori
package main

import (
	"errors"
	"fmt"
	"goodcheckgo/foolingprogram"
	"goodcheckgo/sitestocheck"
	"goodcheckgo/strategies"
	"goodcheckgo/utils"
	"io"
	"log"
	"net/http"
	"net/http/httptrace"
	"os"
	"path/filepath"
	"strings"
	"sync"
	"time"

	gochoice "github.com/TwiN/go-choice"
)

const (
	VERSION        = "0.2.1"
	CONFIGFILENAME = "config.ini"

	LOGSFOLDER       = "Logs"
	CHECKLISTSFOLDER = "Checklists"
	STRATEGIESFOLDER = "StrategiesGo"
	PAYLOADSFOLDER   = "Payloads"
)

type Options struct {
	connTimeout      int
	fakeSni          string
	fakeHexRaw       string
	payloadTLS       string
	payloadUDP       string
	programExtraKeys string
}

var (
	options = Options{
		connTimeout:      2,
		fakeSni:          "www.google.com",
		fakeHexRaw:       "1603030135010001310303424143facf5c983ac8ff20b819cfd634cbf5143c0005b2b8b142a6cd335012c220008969b6b387683dedb4114d466ca90be3212b2bde0c4f56261a9801",
		payloadTLS:       "tls_earth_google_com.bin",
		payloadUDP:       "quic_ietf_www_google_com.bin",
		programExtraKeys: "",
	}

	currentDirectory string

	strategiesToUse []strategies.Strategy
	sitesToCheck    []sitestocheck.SiteToCheck

	gdpi                     foolingprogram.FoolingProg
	zapret                   foolingprogram.FoolingProg
	ciadpi                   foolingprogram.FoolingProg
	availableFoolingPrograms []string
)

func init() {
	var err error

	//Reading current directory
	currentDirectory, err = os.Getwd()
	if err != nil {
		fmt.Println(err)
		fmt.Scanln()
		os.Exit(1)
	}

	//Creating log
	createLog(LOGSFOLDER)

	//Reading config - General
	log.Printf("\nReading config: %s\n", CONFIGFILENAME)
	options.connTimeout = utils.LookForIntOptionInConfig(CONFIGFILENAME, "ConnTimeout", options.connTimeout)

	//Reading config - Fooling-related
	options.fakeSni = utils.LookForStringOptionInConfig(CONFIGFILENAME, "FakeSni", options.fakeSni)
	options.fakeHexRaw = utils.LookForStringOptionInConfig(CONFIGFILENAME, "FakeHexRaw", options.fakeHexRaw)
	options.payloadTLS = utils.LookForStringOptionInConfig(CONFIGFILENAME, "PayloadTLS", options.payloadTLS)
	options.payloadUDP = utils.LookForStringOptionInConfig(CONFIGFILENAME, "PayloadUDP", options.payloadUDP)

	//Reading config - Programs
	gdpi = setUpFoolingProgram("GdpiName", "GdpiPath", "GdpiExecutable", "GdpiServiceName")
	zapret = setUpFoolingProgram("ZapretName", "ZapretPath", "ZapretExecutable", "ZapretServiceName")
	ciadpi = setUpFoolingProgram("ByeDPIName", "ByeDPIPath", "ByeDPIExecutable", "ByeDPIServiceName")

	//If fooling programs aren't found in config-specified location - we'll try to find them by themselves
	if !gdpi.IsExist {
		log.Printf("GoodbyeDPI not found, looking some more...\n")
		gdpi = foolingprogram.NewFoolingProgram("GoodbyeDPI", filepath.Join(currentDirectory, "goodbyedpi.exe"), "GoodbyeDPI")
	}
	if !gdpi.IsExist {
		log.Printf("GoodbyeDPI not found, looking some more...\n")
		gdpi = foolingprogram.NewFoolingProgram("GoodbyeDPI", filepath.Join(currentDirectory, "x86_64", "goodbyedpi.exe"), "GoodbyeDPI")
	}

}

func main() {

	//User selecting fooling program
	programToUse, err := userChoosingProgramToUse(availableFoolingPrograms)
	check(err)

	//User selecting strategy list
	strategiesToUse, options.programExtraKeys, err = userChoosingStrategiesToUse(programToUse)
	check(err)

	//User selecting checklist
	sitesToCheck, err = userChoosingSitesToCheck()
	check(err)

	//Main loop
	totalStrats := len(strategiesToUse)
	totalSites := len(sitesToCheck)
	startT := time.Now()
	log.Printf("\nTotal strategies found: %d\nTotal sites in checklist: %d\n\nTest starting up at %s\n\n", totalStrats, totalSites, startT.String())
	for i := 0; i < totalStrats; i++ {
		log.Printf("Launching %s with a strategy %d/%d: %s\n", programToUse.Name, (i + 1), totalStrats, strategiesToUse[i].StrategyKeys)
		err = programToUse.StartWithArguments(strategiesToUse[i].StrategyKeys)
		check(err)

		log.Println("Making requests...")
		wg := sync.WaitGroup{}
		for i := 0; i < totalSites; i++ {
			wg.Add(1)
			go sendRequest(&wg, &sitesToCheck[i])
		}
		wg.Wait()

		log.Println("Terminating program...")
		err = programToUse.Stop()
		check(err)

		log.Println("Displaying results...")
		successes := 0
		for _, site := range sitesToCheck {
			if site.ResponseCode != 0 {
				log.Printf("WORKING		URL: %s | IP: %s | CODE: %d %s\n", site.WebAddress, site.IP, site.ResponseCode, http.StatusText(site.ResponseCode))
				successes++
			} else {
				log.Printf("NOT WORKING	URL: %s | IP: %s | CODE: %d %s\n", site.WebAddress, site.IP, site.ResponseCode, http.StatusText(site.ResponseCode))
			}
		}
		strategiesToUse[i].Successes = successes
		log.Printf("Successes: %d/%d\n\n", successes, totalSites)
	}

	//Results showcase
	endT := time.Now()
	log.Printf("All strategies have been tested, displaying final results\n")

	for j := 0; j <= totalSites; j++ {
		var lines []string
		for _, strat := range strategiesToUse {
			if strat.Successes == j {
				lines = append(lines, strat.StrategyKeys)
			}
		}
		if lines != nil {
			log.Printf("\nStrategies with %d/%d successes:\n", j, totalSites)
			for _, line := range lines {
				log.Println(line)
			}
		}
	}

	log.Printf("\nTest ended at %s\n", endT.String())
	log.Printf("Total time taken: %s\n", endT.Sub(startT).String())
	fmt.Scanln()
	log.Println("Exiting...")
	os.Exit(0)
}

func sendRequest(wg *sync.WaitGroup, site *sitestocheck.SiteToCheck) {
	defer wg.Done()

	_request, _requestError := http.NewRequest("GET", site.WebAddress, nil)
	if _requestError != nil {
		site.ResponseCode = 0
		//_request.Body.Close()
		return
	}

	_trace := &httptrace.ClientTrace{
		GotConn: func(connInfo httptrace.GotConnInfo) {
			site.IP = connInfo.Conn.RemoteAddr().String()
		},
	}
	_request = _request.WithContext(httptrace.WithClientTrace(_request.Context(), _trace))

	// _transport := &http.Transport{
	// 	MaxIdleConns:       300,
	// 	IdleConnTimeout:    5 * time.Second,
	// 	DisableCompression: true,
	// }
	_client := &http.Client{
		//Transport: _transport,
		Timeout: time.Duration(options.connTimeout) * time.Second,
	}

	_response, _responseError := _client.Do(_request)
	if _responseError != nil {
		site.ResponseCode = 0
		//_response.Body.Close()
		return
	}

	site.ResponseCode = _response.StatusCode
}

func userChoosingProgramToUse(choices []string) (*foolingprogram.FoolingProg, error) {
	log.Printf("\nProgram selection\n")
	if len(availableFoolingPrograms) == 0 {
		return nil, errors.New("can't find any programs")
	}
	choices = append(choices, "Exit")
	log.Println("Offering choice")
	choice, _, err := gochoice.Pick(
		"Choose a program to use:",
		choices,
	)
	if err != nil {
		return nil, err
	}
	switch choice {
	case gdpi.Name:
		log.Printf("Proceeding with: %s\n", choice)
		return &gdpi, nil
	case zapret.Name:
		log.Printf("Proceeding with: %s\n", choice)
		return &zapret, nil
	case ciadpi.Name:
		log.Printf("Proceeding with: %s\n", choice)
		return &ciadpi, nil
	case "Exit":
		return nil, errors.New("terminating by user's choice")
	}
	return nil, errors.New("unknown error during program selection")
}

func userChoosingStrategiesToUse(program *foolingprogram.FoolingProg) ([]strategies.Strategy, string, error) {
	log.Printf("\nStrategy selection\n")
	fullpath := filepath.Join(currentDirectory, STRATEGIESFOLDER, program.Name)
	entries, err := os.ReadDir(fullpath)
	if err != nil {
		return nil, "", err
	}
	log.Printf("Reading folder: %s\n", fullpath)
	var strategiesListsInFolder []string
	for _, e := range entries {
		if !e.IsDir() {
			strategiesListsInFolder = append(strategiesListsInFolder, e.Name())
		}
	}
	if len(strategiesListsInFolder) == 0 {
		return nil, "", errors.New("can't find any strategy lists")
	}
	strategiesListsInFolder = append(strategiesListsInFolder, "Exit")
	log.Println("Offering choice")
	choice, _, err := gochoice.Pick(
		"Choose strategy list to use:",
		strategiesListsInFolder,
	)
	if err != nil {
		return nil, "", err
	}
	if choice == "Exit" {
		return nil, "", errors.New("terminating by user's choice")
	}
	log.Printf("Proceeding with: %s\nReading file...\n", choice)

	s, o, err := strategies.ReadStrategiesFile(filepath.Join(fullpath, choice))
	if err != nil {
		return nil, "", err
	}
	if len(s) == 0 {
		return nil, "", errors.New("strategy list is empty")
	}

	log.Printf("Parsing strategies...\n\n")
	for i := 0; i < len(s); i++ {
		pTLS := filepath.Join(PAYLOADSFOLDER, options.payloadTLS)
		pUDP := filepath.Join(PAYLOADSFOLDER, options.payloadUDP)
		replacer := strings.NewReplacer("FAKEHEX", options.fakeHexRaw, "FAKESNI", options.fakeSni, "PAYLOADTLS", pTLS, "PAYLOADUDP", pUDP)
		s[i].StrategyKeys = replacer.Replace(s[i].StrategyKeys)
		log.Println("Strategy found:", s[i].StrategyKeys)
	}
	return s, o, nil
}

func userChoosingSitesToCheck() ([]sitestocheck.SiteToCheck, error) {
	log.Printf("\nChecklist selection\n")
	fullpath := filepath.Join(currentDirectory, CHECKLISTSFOLDER)
	entries, err := os.ReadDir(fullpath)
	if err != nil {
		return nil, err
	}
	log.Printf("Reading folder: %s\n", fullpath)
	var checkListsInFolder []string
	for _, e := range entries {
		if !e.IsDir() {
			checkListsInFolder = append(checkListsInFolder, e.Name())
		}
	}
	if len(checkListsInFolder) == 0 {
		return nil, errors.New("can't find any checklists")
	}
	checkListsInFolder = append(checkListsInFolder, "Exit")
	log.Println("Offering choice")
	choice, _, err := gochoice.Pick(
		"Choose checklist to use:",
		checkListsInFolder,
	)
	if err != nil {
		return nil, err
	}
	if choice == "Exit" {
		return nil, errors.New("terminating by user's choice")
	}
	log.Printf("Proceeding with: %s\nReading file...\n\n", choice)

	s, err := sitestocheck.ReadChecklistFile(filepath.Join(fullpath, choice))
	if err != nil {
		return nil, err
	}
	return s, nil
}

func setUpFoolingProgram(_name string, _path string, _exe string, _servicename string) foolingprogram.FoolingProg {
	name := utils.LookForStringOptionInConfig(CONFIGFILENAME, _name, "UnknownName")
	path := utils.LookForStringOptionInConfig(CONFIGFILENAME, _path, "UnknownPath")
	exe := utils.LookForStringOptionInConfig(CONFIGFILENAME, _exe, "UnknownExecutable")
	sname := utils.LookForStringOptionInConfig(CONFIGFILENAME, _servicename, "UnknownServiceName")

	fullpath := filepath.Join(path, exe)

	prog := foolingprogram.NewFoolingProgram(
		name,
		fullpath,
		sname,
	)

	if prog.IsExist {
		availableFoolingPrograms = append(availableFoolingPrograms, prog.Name)
	}

	return prog
}

func createLog(logsFolder string) {
	pathToLog := filepath.Join(currentDirectory, logsFolder, "logfile.log")
	l, err := os.OpenFile(pathToLog, os.O_WRONLY|os.O_CREATE|os.O_APPEND, 0644)
	if err != nil {
		fmt.Println(err)
		fmt.Scanln()
		os.Exit(1)
	}
	mw := io.MultiWriter(os.Stdout, l)
	// defer l.Close()
	//log = log.New(l, "", 0)
	log.SetFlags(0)
	log.SetOutput(mw)
	log.Println("Log successfully created at", time.Now())
}

func check(err error) {
	if err != nil {
		log.Println("Error:", err)
		fmt.Scanln()
		log.Println("Exiting...")
		os.Exit(1)
	}
}
