// by Ori
package main

import (
	"bufio"
	"errors"
	"fmt"
	"io"
	"log"
	"math/rand/v2"
	"os"
	"os/exec"
	"path/filepath"
	"runtime"
	"strconv"
	"strings"
	"syscall"
	"time"

	"golang.org/x/sys/windows"

	gochoice "github.com/TwiN/go-choice"
)

const (
	VERSION     = "0.8"
	PROGRAMNAME = "PayloadWorks"

	CONFIGFILENAME     = "config_PW.ini"
	BINPAYLOADTEMPFILE = "temp.bin"
	CURLFOLDER         = "Curl"
	CURL86SUBFOLDER    = "x86"
	CURL64SUBFOLDER    = "x86_64"
	CURLEXENAME        = "curl.exe"
	PAYLOADSFOLDER     = "Payloads"
)

type strategy struct {
	ID int
	//mode: -1=unset; 1=tls; 2=quic; 3=unudp
	mode         int
	strategyKeys []string
}

var strategiesNum int = -1

func newStrategy(_keys []string, _mode string) strategy {
	//mode: -1=unset; 1=tls; 2=quic; 3=unknown udp
	strategiesNum++
	m := -1
	switch _mode {
	case "tls":
		m = 1
	case "quic":
		m = 2
	case "unudp":
		m = 3
	default:
		check(fmt.Errorf("unacceptable mode value for new strategy"))
	}
	s := strategy{
		ID:           strategiesNum,
		mode:         m,
		strategyKeys: _keys,
	}
	return s
}

func (s strategy) showMode() string {
	switch s.mode {
	case -1:
		return "UNSET"
	case 1:
		return "TLS"
	case 2:
		return "QUIC"
	case 3:
		return "UNKNOWN UDP"
	default:
		check(fmt.Errorf("mode '%d' for strategy %s is unacceptable", s.mode, s.strategyKeys))
		return "ERROR"
	}
}

var (

	//this will be set in init
	currentDirectory           string
	zapretFullPathToExecutable string
	curlRetries                int
	replaceWithZeroes          bool
	siteToCheck                string
	curlExe                    string
	strategies                 []strategy

	//this will be set in main
	binPayloadFile  string
	strategyToUseID = -1

	//this can be set here
	curlArguments = []string{
		"-s", "-o NUL", "-m 2", `-w %{response_code}`,
	}
	errExitByChoice = errors.New("terminating by user's choice")
)

func init() {

	if !amAdmin() {
		err := runMeElevated()
		check(err)
		os.Exit(0)
	}

	createLog()

	var err error
	currentDirectory, err = os.Getwd()
	check(err)

	//Reading config
	s, err := lookForStringOptionInConfig("ZapretFullPathToExe")
	check(err)
	zapretFullPathToExecutable = s
	i, err := lookForIntOptionInConfig("CurlRetries")
	check(err)
	curlRetries = i
	b, err := lookForBoolOptionInConfig("TryToReplaceBytesWithZeroes")
	check(err)
	replaceWithZeroes = b
	s, err = lookForStringOptionInConfig("SiteToCheck")
	check(err)
	siteToCheck = s

	if _, err = os.Stat(zapretFullPathToExecutable); os.IsNotExist(err) {
		check(err)
	}

	if is64bit() {
		curlExe = filepath.Join(currentDirectory, CURLFOLDER, CURL64SUBFOLDER, CURLEXENAME)
	} else {
		curlExe = filepath.Join(currentDirectory, CURLFOLDER, CURL86SUBFOLDER, CURLEXENAME)
	}
	if _, err = os.Stat(curlExe); os.IsNotExist(err) {
		check(err)
	}

	strategies = append(strategies,
		newStrategy([]string{
			"--wf-tcp=443", "--dpi-desync=fake", "--dpi-desync-fooling=badseq",
		}, "tls"),
		newStrategy([]string{
			"--wf-tcp=443", "--dpi-desync=fake", "--dpi-desync-fooling=badseq", "--dpi-desync-repeats=7",
		}, "tls"),
		newStrategy([]string{
			"--wf-tcp=443", "--dpi-desync=fake,split2", "--dpi-desync-split-tls=sni", "--dpi-desync-fooling=badseq",
		}, "tls"),
		newStrategy([]string{
			"--wf-tcp=443", "--dpi-desync=fake,split2", "--dpi-desync-split-tls=sni", "--dpi-desync-fooling=badseq", "--dpi-desync-repeats=7",
		}, "tls"),
		newStrategy([]string{
			"--wf-tcp=443", "--dpi-desync=fake,split", "--dpi-desync-split-tls=sni", "--dpi-desync-fooling=badseq",
		}, "tls"),
		newStrategy([]string{
			"--wf-tcp=443", "--dpi-desync=fake,split", "--dpi-desync-split-tls=sni", "--dpi-desync-fooling=badseq", "--dpi-desync-repeats=7",
		}, "tls"),
		newStrategy([]string{
			"--wf-tcp=443", "--dpi-desync=fake,disorder2", "--dpi-desync-fooling=badseq",
		}, "tls"),
		newStrategy([]string{
			"--wf-tcp=443", "--dpi-desync=fake,disorder2", "--dpi-desync-fooling=badseq", "--dpi-desync-repeats=7",
		}, "tls"),
		newStrategy([]string{
			"--wf-tcp=443", "--dpi-desync=fake,disorder", "--dpi-desync-fooling=badseq",
		}, "tls"),
		newStrategy([]string{
			"--wf-tcp=443", "--dpi-desync=fake,disorder", "--dpi-desync-fooling=badseq", "--dpi-desync-repeats=7",
		}, "tls"),
		newStrategy([]string{
			"--wf-udp=443", "--dpi-desync=fake", "--dpi-desync-repeats=2",
		}, "quic"),
		newStrategy([]string{
			"--wf-udp=443", "--dpi-desync=fake", "--dpi-desync-repeats=6",
		}, "quic"),
		newStrategy([]string{
			"--wf-udp=443", "--dpi-desync=fake", "--dpi-desync-repeats=11",
		}, "quic"),
		newStrategy([]string{
			"--wf-udp=443", "--dpi-desync=fake", "--dpi-desync-repeats=20",
		}, "quic"),
		newStrategy([]string{
			"--wf-udp=443-65535", "--dpi-desync=fake", "--dpi-desync-any-protocol",
		}, "unudp"),
	)

}

func main() {

	//User selecting payload
	var err error
	binPayloadFile, err = userSelectingPayload()
	check(err)

	//User selecting strategy
	strategyToUseID, err = userSelectingStrategy()
	check(err)

	//Modifying curl arguments
	if strategies[strategyToUseID].mode == 2 || strategies[strategyToUseID].mode == 3 {
		curlArguments = append(curlArguments, "--http3-only")
	}
	curlArguments = append(curlArguments, siteToCheck)

	log.Printf("Proceeding with payload: %s\n\n", binPayloadFile)
	log.Printf("Proceeding with strategy: %s\n\n", strategies[strategyToUseID].strategyKeys)
	log.Printf("Proceeding with curl params: [%s] %s\n\n", curlExe, curlArguments)
	log.Printf("--------------------------------------------\nMAKE SURE THAT YOU HAVE DISABLED ALL RUNNING FOOLING PROGRAMS AND SERVICES: THIS PROGRAM WON'T DO IT FOR YOU\n")
	log.Printf("MAKE SURE THAT CURL AREN'T BLOCKED BY YOUR FIREWALL/ANTIVIRUS\n--------------------------------------------\n")
	fmt.Printf("\nPress [ENTER] to start...\n")
	fmt.Scanln()

	//Read payload as bytes
	log.Printf("\nProcessing file: %s\n", binPayloadFile)
	hexBytesArray, err := readFromFile(binPayloadFile)
	check(err)
	hexRawStream := fmt.Sprintf("%x", hexBytesArray)
	log.Println("Starting hex stream:", hexRawStream)

	//We need to check that payload is effecive to begin with
	isSuccessful := foolAndCurlAndInterpret(binPayloadFile)
	if !isSuccessful {
		log.Printf("\nThis payload with this strategy aren't effective at all!\n\n")
		fmt.Println("Press [ENTER] to exit...")
		fmt.Scanln()
		os.Exit(0)
	}

	//Here we starting to do stuff with it: truncating for now
	truncatedBytesArray1 := truncateAndTest(hexBytesArray, 100)
	truncatedBytesArray2 := truncateAndTest(truncatedBytesArray1, 20)
	truncatedBytesArray3 := truncateAndTest(truncatedBytesArray2, 4)
	truncatedBytesArray4 := truncateAndTest(truncatedBytesArray3, 1)

	//Checking effectivenes again just to be safe
	finalTruncatedBytesArray := truncateFinalTest(truncatedBytesArray4, truncatedBytesArray3, truncatedBytesArray2, truncatedBytesArray1)

	//Showcasing the result of truncation
	finalTruncatedHexRaw := fmt.Sprintf("%x", finalTruncatedBytesArray)
	log.Println("Final result of truncation:", finalTruncatedHexRaw)

	//Lets try to replace bytes in payload with zeroes or trash
	var finalArray []byte
	if replaceWithZeroes {
		finalArray = replaceBytesMain(finalTruncatedBytesArray)
	} else {
		log.Println("'Replace with zeroes' disabled, skipping")
		finalArray = finalTruncatedBytesArray
	}

	//Showcasing final result
	finalHexRaw := fmt.Sprintf("%x", finalArray)
	log.Printf("\nFinal result of replacements: %s\n\n", finalHexRaw)

	//...saving as .bin
	t := time.Now().Format("2006-01-02_15-04-05")
	filename1 := strings.Split(binPayloadFile, ".")[0] + "_squeezed_" + t + ".bin"
	err = saveToFileBinary(filename1, finalArray)
	check(err)
	log.Printf("Saved to %s\n", filename1)

	//...saving as .txt
	filename2 := strings.Split(binPayloadFile, ".")[0] + "_squeezed_" + t + ".txt"
	finalHexRawFormatted, err := formatHex(finalHexRaw)
	check(err)
	err = saveToFile(filename2, finalHexRaw, finalHexRawFormatted)
	check(err)
	log.Printf("Saved to %s\n", filename2)

	//removing temp file
	if _, err := os.Stat(BINPAYLOADTEMPFILE); err == nil {
		err = os.Remove(BINPAYLOADTEMPFILE)
		check(err)
	}

	log.Printf("\nAll done!\n\n")
	fmt.Println("Press [ENTER] to exit...")
	fmt.Scanln()

	os.Exit(0)

}

func userSelectingPayload() (string, error) {

	path := filepath.Join(currentDirectory, PAYLOADSFOLDER)
	entries, err := os.ReadDir(path)
	if err != nil {
		return "", fmt.Errorf("can't read payloads folder: %w", err)
	}

	log.Printf("Reading payloads folder: %s\n", path)
	var payloads []string
	for _, e := range entries {
		if !e.IsDir() && isExtension(e.Name(), "bin") {
			log.Printf("Payload found: %s\n", e.Name())
			payloads = append(payloads, e.Name())
		}
	}
	if len(payloads) == 0 {
		return "", fmt.Errorf("no payloads in folder")
	}

	payloads = append(payloads, "Exit")
	log.Println("Offering choice")
	choice, _, err := gochoice.Pick(
		"Which payload to use:",
		payloads,
	)
	if err != nil {
		return "", fmt.Errorf("problem during choice: %w", err)
	}
	if choice == "Exit" {
		return "", errExitByChoice
	}

	return filepath.Join(currentDirectory, PAYLOADSFOLDER, choice), nil
}

func userSelectingStrategy() (int, error) {

	var c []string
	for _, strat := range strategies {
		c = append(c, fmt.Sprintf("%s: %s", strat.showMode(), strat.strategyKeys))
	}

	c = append(c, "Exit")
	log.Println("Offering choice")
	choice, choiceN, err := gochoice.Pick(
		"Which strategy to use:",
		c,
	)
	if err != nil {
		return -1, fmt.Errorf("problem during choice: %w", err)
	}
	if choice == "Exit" {
		return -1, errExitByChoice
	}
	return choiceN, nil
}

func isExtension(path string, ext string) bool {
	s := strings.Split(path, ".")
	e := s[len(s)-1]
	return e == ext
}

func replaceBytesMain(array []byte) []byte {

	var trashedArray []byte = array

	for i := (len(trashedArray) - 1); i >= 0; i-- {
		log.Println("Current hex stream:", fmt.Sprintf("%x", trashedArray))
		var trashByte byte = byte(rand.UintN(255))
		var originalByte byte = array[i]
		if replaceThisByteAndTest(trashedArray, i, 0) {
			trashedArray[i] = 0
			continue
		}
		if replaceThisByteAndTest(trashedArray, i, trashByte) {
			trashedArray[i] = trashByte
			continue
		}
		log.Printf("Using original value: %x\n", originalByte)
		trashedArray[i] = originalByte
	}

	return trashedArray
}

func replaceThisByteAndTest(array []byte, num int, value byte) bool {

	log.Printf("Trying to replace byte number %d: %x - > %x\n", num, array[num], value)

	array[num] = value
	err := saveToFileBinary(BINPAYLOADTEMPFILE, array)
	check(err)

	if foolAndCurlAndInterpret(BINPAYLOADTEMPFILE) {
		log.Println("Success")
		return true
	} else {
		log.Println("Failure")
		return false
	}
}

func truncateFinalTest(arrays ...[]byte) []byte {

	for _, array := range arrays {
		saveToFileBinary(BINPAYLOADTEMPFILE, array)
		isSuccessful := foolAndCurlAndInterpret(BINPAYLOADTEMPFILE)
		if !isSuccessful {
			log.Println("Oops! We truncated too much...")
		} else {
			log.Println("Seems okay...")
			return array
		}
	}

	check(fmt.Errorf("unexpected: all payloads failed"))
	return nil
}

func truncateAndTest(byteArray []byte, howMuchToCut int) []byte {

	truncatedBytesArray := byteArray
	previousTruncatedBytesArray := truncatedBytesArray

	for i := len(byteArray); i > 0; i = i - howMuchToCut {

		log.Printf("Truncating by %d...\n", howMuchToCut)
		if i <= howMuchToCut {
			log.Println("It's already too short, stopping this cycle")
			break
		} else {
			truncatedBytesArray = truncateBytesArray(truncatedBytesArray, i)
			truncatedHexRaw := fmt.Sprintf("%x", truncatedBytesArray)
			log.Println("Truncated hex stream:", truncatedHexRaw)
		}

		log.Println("Converting to a temporary file...")
		saveToFileBinary(BINPAYLOADTEMPFILE, truncatedBytesArray)

		log.Println("Checking if payload is effective...")
		isSuccessful := foolAndCurlAndInterpret(BINPAYLOADTEMPFILE)
		if !isSuccessful {
			log.Println("It's failed, stopping this cycle")
			break
		} else {
			log.Println("It's succeeded, truncating more")
			previousTruncatedBytesArray = truncatedBytesArray
		}
	}

	return previousTruncatedBytesArray
}

func truncateBytesArray(array []byte, position int) []byte {
	return array[:position]
}

func foolAndCurlAndInterpret(payload string) bool {

	args := strategies[strategyToUseID].strategyKeys
	switch strategies[strategyToUseID].mode {
	case 1:
		args = append(args, "--dpi-desync-fake-tls="+payload)
	case 2:
		args = append(args, "--dpi-desync-fake-quic="+payload)
	case 3:
		args = append(args, "--dpi-desync-fake-unknown-udp="+payload)
	default:
		check(fmt.Errorf("mode '%d' for strategy %s is unacceptable", strategies[strategyToUseID].mode, strategies[strategyToUseID].strategyKeys))
	}

	log.Printf("Launching Zapret with arguments: %s\n", args)
	exeZapret, err := startWithArguments(zapretFullPathToExecutable, args)
	check(err)

	time.Sleep(1 * time.Second)

	isWorking := true
	retries := curlRetries

	for retries > 0 {
		log.Println("Launching curl, tries left:", retries)
		time.Sleep(200 * time.Millisecond)
		exeCurl, outputCurl, err := startWithArgumentsAndReadTheOutput(curlExe, curlArguments)
		check(err)
		err = stop(exeCurl)
		check(err)
		outputCurl = strings.Split(outputCurl, " ")[1]
		log.Println("Response code:", outputCurl)
		if outputCurl == "000" {
			isWorking = false
			break
		}
		retries--
	}

	log.Println("Terminating Zapret")
	err = stop(exeZapret)
	check(err)

	time.Sleep(1 * time.Second)

	return isWorking
}

func readFromFile(filename string) ([]byte, error) {

	b, err := os.ReadFile(filename)
	if err != nil {
		return nil, fmt.Errorf("can't read file: %w", err)
	}

	return b, nil
}

func formatHex(hex string) (string, error) {

	if hex == "" {
		return "", fmt.Errorf("can't convert: hex is empty")
	}

	formattedString := ":"
	for i := 0; i < len(hex); i = i + 2 {
		formattedByte := "\\x" + string(hex[i]) + string(hex[i+1])
		formattedString = formattedString + formattedByte
	}

	return formattedString, nil
}

func saveToFile(filename string, values ...string) error {

	var textToWrite string
	for _, value := range values {
		textToWrite = textToWrite + value + "\n\n"
	}

	b := []byte(textToWrite)
	err := os.WriteFile(filename, b, 0200)
	if err != nil {
		return fmt.Errorf("can't write fo file: %w", err)
	}

	return nil
}

func saveToFileBinary(filename string, value []byte) error {

	err := os.WriteFile(filename, value, 0200)
	if err != nil {
		return fmt.Errorf("can't write fo file: %w", err)
	}

	return nil
}

func startWithArguments(filepath string, arguments []string) (*exec.Cmd, error) {

	exe := exec.Command(filepath, arguments...)
	//prog.SysProcAttr = &syscall.SysProcAttr{CmdLine: " " + arguments}

	err := exe.Start()
	if err != nil {
		return exe, err
	}

	return exe, nil
}

func startWithArgumentsAndReadTheOutput(filepath string, arguments []string) (*exec.Cmd, string, error) {

	exe := exec.Command(filepath, arguments...)
	//exe.SysProcAttr = &syscall.SysProcAttr{CmdLine: " " + arguments}

	out, err := exe.StdoutPipe()
	if err != nil {
		return exe, "", fmt.Errorf("can't pipe: %w", err)
	}

	r := bufio.NewReader(out)
	err = exe.Start()
	if err != nil {
		return exe, "", fmt.Errorf("can't start program: %w", err)
	}

	s, err := io.ReadAll(r)
	if err != nil {
		return exe, "", fmt.Errorf("can't read pipe: %w", err)
	}

	exe.Wait()
	// if err != nil {
	// 	return exe, "", fmt.Errorf("can't close pipe: %w", err)
	// }

	return exe, string(s), nil
}

func stop(exe *exec.Cmd) error {

	exist, err := pidExists(int32(exe.Process.Pid))
	if err != nil {
		return fmt.Errorf("failed to properly check if process do exist: %w", err)
	}

	if exist {
		err = exe.Process.Kill()
		if err != nil {
			return fmt.Errorf("failed to properly kill process: %w", err)
		}
	} else {
		//log.Println("Can't find process to terminate: either it wasn't properly started, has crushed, was exited by itself or something else terminated it")
	}

	return nil
}

func IsCommented(line string, symbol string) bool {
	if line != "" {
		return string(line[0]) == symbol
	}
	return true
}

func lookForRawOptionInConfig(optionName string) (string, error) {

	c, err := os.Open(CONFIGFILENAME)
	if err != nil {
		return "", fmt.Errorf("can't read config file: %w", err)
	}
	defer c.Close()

	scan := bufio.NewScanner(c)
	for scan.Scan() {
		if !IsCommented(scan.Text(), "[") && !IsCommented(scan.Text(), "/") {
			param := strings.Split(scan.Text(), `=`)
			if param[0] == optionName {
				if param[1] != "" {
					return param[1], nil
				} else {
					return "", fmt.Errorf("value is empty")
				}
			}
		}
	}

	return "", fmt.Errorf("no such option in config")
}

func lookForStringOptionInConfig(optionName string) (string, error) {
	o, err := lookForRawOptionInConfig(optionName)
	if err != nil {
		return "", fmt.Errorf("can't set string option '%s': %w", optionName, err)
	}
	log.Printf("Set '%s': %s\n", optionName, o)
	return o, nil
}

func lookForBoolOptionInConfig(optionName string) (bool, error) {
	o, err := lookForRawOptionInConfig(optionName)
	if err != nil {
		return false, fmt.Errorf("can't set boolean option '%s': %w", optionName, err)
	}
	v, err := strconv.ParseBool(o)
	if err != nil {
		return false, fmt.Errorf("can't set boolean option '%s': %w", optionName, err)
	}
	log.Printf("Set '%s': %s\n", optionName, o)
	return v, nil
}

func lookForIntOptionInConfig(optionName string) (int, error) {
	o, err := lookForRawOptionInConfig(optionName)
	if err != nil {
		return -1, fmt.Errorf("can't set integer option '%s': %w", optionName, err)
	}
	v, err := strconv.Atoi(o)
	if err != nil {
		return -1, fmt.Errorf("can't set integer option '%s': %w", optionName, err)
	}
	log.Printf("Set '%s': %s\n", optionName, o)
	return v, nil
}

func createLog() {
	//t := time.Now().Format("2006-01-02_15-04-05")
	//n := "logfile_" + t + ".log"
	n := "logfile.log"
	if _, err := os.Stat(n); err == nil {
		err = os.Remove(n)
		check(err)
	}
	l, err := os.OpenFile(n, os.O_WRONLY|os.O_CREATE|os.O_APPEND, 0200)
	check(err)
	mw := io.MultiWriter(os.Stdout, l)
	// defer l.Close()
	//log = log.New(l, "", 0)
	log.SetFlags(0)
	log.SetOutput(mw)
	log.Println("Log created at", time.Now())
	log.Printf("%s v%s\n\n", PROGRAMNAME, VERSION)
}

func is64bit() bool {
	arch := runtime.GOARCH
	if arch == "amd64" || arch == "arm64" || arch == "arm64be" || arch == "loong64" || arch == "mips64" || arch == "mips64le" || arch == "ppc64" || arch == "ppc64le" || arch == "riscv64" || arch == "s390x" || arch == "sparc64" || arch == "wasm" {
		return true
	}
	return false
}

func pidExists(pid int32) (bool, error) {
	// code by shirou
	if pid == 0 { // special case for pid 0 System Idle Process
		return true, nil
	}
	if pid < 0 {
		return false, fmt.Errorf("invalid pid %v", pid)
	}
	if pid%4 != 0 {
		// OpenProcess will succeed even on non-existing pid here https://devblogs.microsoft.com/oldnewthing/20080606-00/?p=22043
		return false, fmt.Errorf("pid %v incorrect: it should be a multiplier of 4", pid)
	}
	const STILL_ACTIVE = 259 // https://docs.microsoft.com/en-us/windows/win32/api/processthreadsapi/nf-processthreadsapi-getexitcodeprocess
	h, err := windows.OpenProcess(windows.PROCESS_QUERY_LIMITED_INFORMATION, false, uint32(pid))
	if err == windows.ERROR_ACCESS_DENIED {
		return true, nil
	}
	if err == windows.ERROR_INVALID_PARAMETER {
		return false, nil
	}
	if err != nil {
		return false, err
	}
	defer syscall.CloseHandle(syscall.Handle(h))
	var exitCode uint32
	err = windows.GetExitCodeProcess(h, &exitCode)
	return exitCode == STILL_ACTIVE, err
}

func amAdmin() bool {
	log.Println("Checking privilegies")
	elevated := windows.GetCurrentProcessToken().IsElevated()
	log.Printf("Admin rights: %v\n", elevated)
	return elevated
}

func runMeElevated() error {
	log.Println("Relaunching with elevation")

	verb := "runas"
	exe, _ := os.Executable()
	cwd, _ := os.Getwd()
	args := strings.Join(os.Args[1:], " ")

	verbPtr, _ := syscall.UTF16PtrFromString(verb)
	exePtr, _ := syscall.UTF16PtrFromString(exe)
	cwdPtr, _ := syscall.UTF16PtrFromString(cwd)
	argPtr, _ := syscall.UTF16PtrFromString(args)

	var showCmd int32 = 1 //SW_NORMAL

	err := windows.ShellExecute(0, verbPtr, exePtr, argPtr, cwdPtr, showCmd)
	return err
}

func check(err error) {
	switch err {
	case nil:
		return
	case errExitByChoice:
		log.Println("Exiting by users choice...")
		os.Exit(0)
	default:
		log.Println("Critical error:", err)
		fmt.Scanln()
		log.Println("Exiting with an error...")
		os.Exit(1)
	}
}
