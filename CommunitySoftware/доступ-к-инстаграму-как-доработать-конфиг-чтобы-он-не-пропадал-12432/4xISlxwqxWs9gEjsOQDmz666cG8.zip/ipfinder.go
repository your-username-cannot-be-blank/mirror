// by Ori
package main

import (
	"encoding/json"
	"flag"
	"fmt"
	"io"
	"log"
	"net"
	"os"
	"os/signal"
	"path/filepath"
	"sort"
	"sync"
	"syscall"
	"time"

	"github.com/AdguardTeam/dnsproxy/upstream"
	"github.com/AdguardTeam/golibs/netutil/sysresolv"
	"github.com/miekg/dns"
)

const (
	PROGRAMNAME = "IP Finder"
	VERSION     = "0.1"
)

type DnsResponse struct {
	Response bool
	Zero     bool
	Answer   []DnsAnswer
}

type DnsAnswer struct {
	A    string
	AAAA string
}

var (
	allReplies []DnsResponse

	errInterrupt error = fmt.Errorf("interrupt")

	flagURL        *string
	flagQuiet      *bool
	flagHelp       *bool
	flagDNS        *string
	flagIPv        *int
	flagTimeout    *int
	flagRetries    *int
	flagSkipVerify *bool
)

func init() {

	// reading args
	flagHelp = flag.Bool("?", false, "display help")
	flagQuiet = flag.Bool("q", false, "activates quiet mode")
	flagURL = flag.String("u", "", "url to process")
	flagDNS = flag.String("d", "", "dns-over-https resolver")
	flagIPv = flag.Int("v", 4, "ip version; either 4 or 6")
	flagTimeout = flag.Int("t", 1, "timeout, in seconds")
	flagRetries = flag.Int("r", 3, "retries on dns request failure")
	flagSkipVerify = flag.Bool("s", false, "whether to skip certificate validation or not")
	flag.Parse()

	if *flagHelp || len(os.Args) == 1 {
		flag.PrintDefaults()
		os.Exit(0)
	}

	// creating logfile
	n := "logfile.log"
	err := createLog(n, *flagQuiet)
	if err != nil {
		check(fmt.Errorf("can't initialize log: %v", err))
	}

	// writing down some basic info into the log
	log.Printf("%s v%s\n", PROGRAMNAME, VERSION)
	log.Printf("\nCommand-line arguments: %q", os.Args[1:])

	log.Printf("\nInit completed\n")
}

func main() {
	go func() {
		sigchan := make(chan os.Signal, 1)
		signal.Notify(sigchan,
			os.Interrupt,
			syscall.SIGTERM, // "the normal way to politely ask a program to terminate"
			syscall.SIGINT,  // Ctrl+C
			syscall.SIGQUIT, // Ctrl-\
			//syscall.SIGKILL, // "always fatal", "SIGKILL and SIGSTOP may not be caught by a program"
			syscall.SIGHUP, // "terminal is disconnected"
		)
		<-sigchan
		check(errInterrupt)
	}()

	for i := 0; i <= 255; i = i + 10 {
		var wg sync.WaitGroup
		for j := 0; j <= 255; j = j + 10 {
			wg.Add(1)
			subnet := fmt.Sprintf("%d.%d.0.0/16", i, j)
			log.Printf("Requesting with subnet '%s'\n", subnet)
			go dnsLookup(&wg, subnet)
		}
		wg.Wait()
	}

	var nonDuplicateReplies []string
	if allReplies != nil {
		for i := 0; i < len(allReplies); i++ {
			if allReplies[i].Answer != nil {
				for j := 0; j < len(allReplies[i].Answer); j++ {
					switch *flagIPv {
					case 4:
						log.Println(allReplies[i].Answer[j].A)
						if nonDuplicateReplies != nil {
							duplicate := false
							for k := 0; k < len(nonDuplicateReplies); k++ {
								if nonDuplicateReplies[k] == allReplies[i].Answer[j].A {
									log.Println("Duplicate found!")
									duplicate = true
									break
								}
							}
							if !duplicate {
								nonDuplicateReplies = append(nonDuplicateReplies, allReplies[i].Answer[j].A)
							}
						} else {
							nonDuplicateReplies = append(nonDuplicateReplies, allReplies[i].Answer[j].A)
						}
					case 6:
						log.Println(allReplies[i].Answer[j].AAAA)
						if nonDuplicateReplies != nil {
							duplicate := false
							for k := 0; k < len(nonDuplicateReplies); k++ {
								if nonDuplicateReplies[k] == allReplies[i].Answer[j].AAAA {
									log.Println("Duplicate found!")
									duplicate = true
									break
								}
							}
							if !duplicate {
								nonDuplicateReplies = append(nonDuplicateReplies, allReplies[i].Answer[j].AAAA)
							}
						} else {
							nonDuplicateReplies = append(nonDuplicateReplies, allReplies[i].Answer[j].AAAA)
						}
					}
				}
			}
		}
	}

	if nonDuplicateReplies != nil {
		sort.Strings(nonDuplicateReplies)
		log.Println("-------------------------------------------")
		for i := 0; i < len(nonDuplicateReplies); i++ {
			log.Println(nonDuplicateReplies[i])
		}
	}
}

func dnsLookup(wg *sync.WaitGroup, _subnet string) {
	defer wg.Done()

	o := &upstream.Options{
		Timeout:            time.Duration(*flagTimeout) * time.Second,
		InsecureSkipVerify: *flagSkipVerify,
		HTTPVersions:       []upstream.HTTPVersion{upstream.HTTPVersion2, upstream.HTTPVersion11},
	}

	_resolver := *flagDNS
	if _resolver == "" {
		systemResolvers, err := sysresolv.NewSystemResolvers(nil, 53)
		if err != nil {
			log.Printf("Can't get system resolvers: %v\n", err)
			return
		}
		_resolver = systemResolvers.Addrs()[0].String()
	}

	u, err := upstream.AddressToUpstream(_resolver, o)
	if err != nil {
		log.Printf("Can't create an upstream: %v\n", err)
		return
	}
	defer u.Close()

	var q = dns.Question{
		Name:   dns.Fqdn(*flagURL),
		Qclass: dns.ClassINET,
	}
	q.Qtype = dns.TypeA
	if *flagIPv == 6 {
		q.Qtype = dns.TypeAAAA
	}

	req := &dns.Msg{}
	req.Id = dns.Id()
	req.RecursionDesired = true
	req.Question = []dns.Question{q}

	_, ipNet, err := net.ParseCIDR(_subnet)
	if err != nil {
		log.Printf("Invalid SUBNET '%s': %v\n", _subnet, err)
		return
	}
	ones, _ := ipNet.Mask.Size()
	subnet := &dns.EDNS0_SUBNET{
		Code:          dns.EDNS0SUBNET,
		Family:        1,
		SourceNetmask: uint8(ones),
		SourceScope:   0,
		Address:       ipNet.IP,
	}

	opt := req.IsEdns0()
	if opt == nil {
		req.SetEdns0(dns.DefaultMsgSize, false)
		opt = req.IsEdns0()
	}
	opt.Option = append(opt.Option, subnet)

	retries := *flagRetries
	var reply *dns.Msg
	for retries >= 0 {
		reply, err = u.Exchange(req)
		if err != nil && retries == 0 {
			log.Printf("can't make DNS request (attempts left %d): %v\n", retries, err)
			return
		} else if err != nil {
			log.Printf("Can't make DNS request (attempts left %d): %v\n", retries, err)
		} else {
			break
		}
		retries--
	}

	var b []byte
	b, err = json.Marshal(reply)
	if err != nil {
		log.Printf("Can't marshal json: %v\n", err)
		return
	}

	var r DnsResponse
	err = json.Unmarshal(b, &r)
	if err != nil {
		log.Printf("Can't unmarshal json: %v\n", err)
		return
	}
	allReplies = append(allReplies, r)
}

func createLog(file string, silentConsole bool) error {
	// removing previous logfile if finded
	if _, err := os.Stat(file); err == nil {
		err = os.Remove(file)
		if err != nil {
			return fmt.Errorf("can't remove a file '%s': %v", file, err)
		}
	}
	// creating log folder if needed
	d := filepath.Dir(file)
	if d != "." {
		if _, err := os.Stat(d); os.IsNotExist(err) {
			err = os.Mkdir(d, 0200)
			if err != nil {
				return fmt.Errorf("can't create a folder '%s': %v", d, err)
			}
		}
	}
	// creating logfile
	f, err := os.OpenFile(file, os.O_WRONLY|os.O_CREATE|os.O_APPEND, 0200)
	if err != nil {
		return fmt.Errorf("can't create a file '%s': %v", file, err)
	}
	// setting output
	if silentConsole {
		log.SetOutput(f)
	} else {
		mw := io.MultiWriter(os.Stdout, f)
		log.SetOutput(mw)
	}
	//defer f.Close()
	//log = log.New(l, "", 0)
	log.SetFlags(0)
	//log.SetOutput(mw)
	log.Println("Log created at", time.Now())

	return nil
}

func check(err error) {
	switch err {
	case nil:
		return
	case errInterrupt:
		log.Printf("\nSignal catched: %v\n", err)
		log.Printf("\nExiting with an interrupt...\n")
		os.Exit(1)
	default:
		log.Printf("\nCritical error: %v\n", err)
		log.Printf("\nExiting with an error...\n")
		os.Exit(1)
	}
}
