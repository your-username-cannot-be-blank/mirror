package main

import (
	"archive/zip"
	"encoding/json"
	"errors"
	"fmt"
	"io"
	"net/http"
	"os"
	"path/filepath"
	"strings"
)

// p.s: спасибо chatgpt

// Variables for paths and GitHub repository
var (
	targetPath      = "./"             // Target directory
	githubRepo      = "bol-van/zapret" // GitHub repository
	tempZipPath     = filepath.Join(os.TempDir(), "zapret.zip")
	tempExtractPath = filepath.Join(os.TempDir(), "zapret_extracted")
)

// Retrieves the latest release `.zip` URL from the specified GitHub repository
func getLatestReleaseZipURL(repo string) (string, error) {
	apiURL := fmt.Sprintf("https://api.github.com/repos/%s/releases/latest", repo)

	resp, err := http.Get(apiURL)
	if err != nil {
		return "", fmt.Errorf("failed to retrieve release information: %v", err)
	}
	defer resp.Body.Close()

	if resp.StatusCode != http.StatusOK {
		return "", fmt.Errorf("unexpected status code: %s", resp.Status)
	}

	var jsonResponse struct {
		Assets []struct {
			Name               string `json:"name"`
			BrowserDownloadURL string `json:"browser_download_url"`
		} `json:"assets"`
	}

	if err := json.NewDecoder(resp.Body).Decode(&jsonResponse); err != nil {
		return "", fmt.Errorf("failed to parse JSON response: %v", err)
	}

	for _, asset := range jsonResponse.Assets {
		if strings.HasSuffix(asset.Name, ".zip") {
			return asset.BrowserDownloadURL, nil
		}
	}
	return "", fmt.Errorf(".zip file not found in the latest release")
}

// Downloads a file from the specified URL to a destination path
func downloadFile(url string, dest string) error {
	resp, err := http.Get(url)
	if err != nil {
		return fmt.Errorf("failed to download file: %v", err)
	}
	defer resp.Body.Close()

	out, err := os.Create(dest)
	if err != nil {
		return fmt.Errorf("failed to create file: %v", err)
	}
	defer out.Close()

	_, err = io.Copy(out, resp.Body)
	return err
}

// Unzips a `.zip` file to a specified destination path
func unzip(src string, dest string) error {
	r, err := zip.OpenReader(src)
	if err != nil {
		return err
	}
	defer r.Close()

	for _, f := range r.File {
		fPath := filepath.Join(dest, f.Name)

		// Prevent zip-slip vulnerability
		if !strings.HasPrefix(fPath, filepath.Clean(dest)+string(os.PathSeparator)) {
			return fmt.Errorf("illegal file path: %s", fPath)
		}

		if f.FileInfo().IsDir() {
			os.MkdirAll(fPath, os.ModePerm)
			continue
		}

		if err := os.MkdirAll(filepath.Dir(fPath), os.ModePerm); err != nil {
			return err
		}

		outFile, err := os.OpenFile(fPath, os.O_WRONLY|os.O_CREATE|os.O_TRUNC, f.Mode())
		if err != nil {
			return err
		}
		defer outFile.Close()

		rc, err := f.Open()
		if err != nil {
			return err
		}
		defer rc.Close()

		if _, err = io.Copy(outFile, rc); err != nil {
			return err
		}
	}
	return nil
}

// Copies files from the extracted nested directory to the target directory
func copyFiles(srcDir, destDir string, filesToCopy []string) error {
	// Identify the nested folder
	var nestedFolder string
	err := filepath.Walk(srcDir, func(path string, info os.FileInfo, err error) error {
		if info.IsDir() && path != srcDir {
			nestedFolder = path
			return filepath.SkipDir
		}
		return nil
	})
	if err != nil {
		return fmt.Errorf("failed to locate nested folder: %v", err)
	}

	// Copy files from the nested directory to the target directory
	for _, folder := range filesToCopy {
		srcPath := filepath.Join(nestedFolder, folder)
		destPath := destDir

		err := filepath.Walk(srcPath, func(path string, info os.FileInfo, err error) error {
			if err != nil {
				return err
			}

			// Skip directories
			if info.IsDir() {
				return nil
			}

			// Copy files
			relPath, err := filepath.Rel(srcPath, path)
			if err != nil {
				return err
			}
			destFilePath := filepath.Join(destPath, relPath)
			if err := os.MkdirAll(filepath.Dir(destFilePath), os.ModePerm); err != nil {
				return err
			}

			srcFile, err := os.Open(path)
			if err != nil {
				return err
			}
			defer srcFile.Close()

			destFile, err := os.Create(destFilePath)
			if err != nil {
				return err
			}
			defer destFile.Close()

			_, err = io.Copy(destFile, srcFile)
			return err
		})

		if err != nil {
			return fmt.Errorf("failed to copy files from %s: %v", srcPath, err)
		}
	}
	return nil
}

// Cleans up temporary files
func cleanUp(paths ...string) {
	for _, path := range paths {
		os.RemoveAll(path)
	}
}

// Main function to check files, download and extract if necessary
func main() {
	const okFile = "ZAPRET_OK"

	f, err := os.Open(okFile)
	if err != nil {
		if !errors.Is(err, os.ErrNotExist) {
			panic(err)
		}
	} else {
		f.Close()
		fmt.Printf("Zapret files OK, or ZAPRET_OK created. Skip downloading.")
		return
	}

	defer cleanUp(tempZipPath, tempExtractPath)

	fmt.Println("Files are missing. Downloading archive...")

	// Get the latest release URL
	zipURL, err := getLatestReleaseZipURL(githubRepo)
	if err != nil {
		fmt.Printf("Error retrieving release: %v\n", err)
		return
	}
	fmt.Printf("Archive URL: %s\n", zipURL)

	// Download the zip file
	if err := downloadFile(zipURL, tempZipPath); err != nil {
		fmt.Printf("Error downloading file: %v\n", err)
		return
	}
	fmt.Println("Archive downloaded.")

	// Extract the zip file
	if err := unzip(tempZipPath, tempExtractPath); err != nil {
		fmt.Printf("Error extracting archive: %v\n", err)
		return
	}
	fmt.Println("Archive extracted.")

	// Copy files to target path
	if err := copyFiles(tempExtractPath, targetPath, []string{"binaries/win64"}); err != nil {
		fmt.Printf("Error copying files: %v\n", err)
		return
	}
	fmt.Println("Files copied to target directory.")

	f, err = os.Create(okFile)
	if err != nil {
		panic(err)
	}
	defer f.Close()
}
