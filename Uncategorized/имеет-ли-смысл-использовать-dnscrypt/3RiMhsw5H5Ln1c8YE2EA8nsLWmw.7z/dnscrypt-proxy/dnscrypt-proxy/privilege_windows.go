package main

import "os"

func (proxy *Proxy) dropPrivilege(userStr string, fds []*os.File) {}
