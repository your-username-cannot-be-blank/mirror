# Minimal example of an empty source list

