//go:build !android

package main

func TimezoneSetup() error {
	return nil
}
