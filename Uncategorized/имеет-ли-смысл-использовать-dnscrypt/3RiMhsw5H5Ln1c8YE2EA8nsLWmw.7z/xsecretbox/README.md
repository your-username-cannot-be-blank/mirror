# xsecretbox

Go implementation of crypto_secretbox_xchacha20poly1305

Uses [aead/chacha20poly1305](https://github.com/aead/chacha20poly1305).

