# clocksmith

A sleep-aware sleep() function, that doesn't pause (for too long) if
the system goes to hibernation.
